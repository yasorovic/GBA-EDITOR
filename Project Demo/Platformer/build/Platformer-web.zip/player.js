globalThis.BACKSTAGE_SHADER_FILES = {"agb001.shader/agb001.fs": "varying vec2 texCoord;\nuniform sampler2D tex;\nuniform vec2 texSize;\n\nvoid main() {\n\tvec4 color = texture2D(tex, texCoord);\n\tvec3 arrayX[3];\n\tarrayX[0] = vec3(0.2, 0.2, 1.0);\n\tarrayX[1] = vec3(0.2, 1.0, 0.2);\n\tarrayX[2] = vec3(1.0, 0.2, 0.2);\n\tvec3 arrayY[4];\n\tarrayY[0] = vec3(1.0, 1.0, 1.0);\n\tarrayY[1] = vec3(1.0, 1.0, 1.0);\n\tarrayY[2] = vec3(1.0, 1.0, 1.0);\n\tarrayY[3] = vec3(0.8, 0.8, 0.8);\n\tcolor.rgb = pow(color.rgb * vec3(0.8, 0.8, 0.8), vec3(1.8, 1.8, 1.8)) + vec3(0.16, 0.16, 0.16);\n\tcolor.rgb *= arrayX[int(mod(texCoord.s * texSize.x * 3.0, 3.0))];\n\tcolor.rgb *= arrayY[int(mod(texCoord.t * texSize.y * 4.0, 4.0))];\n\tcolor.a = 0.5;\n\tgl_FragColor = color;\n}\n", "agb001.shader/manifest.ini": "[shader]\nname=AGB-001\nauthor=endrift\ndescription=A glorious recreation of the original Game Boy Advance\npasses=1\n\n[pass.0]\nfragmentShader=agb001.fs\nblend=1\nwidth=-3\nheight=-4\n", "ags001.shader/ags001-light.fs": "varying vec2 texCoord;\nuniform sampler2D tex;\nuniform float reflectionBrightness;\nuniform vec2 reflectionDistance;\nuniform float lightBrightness;\n\nconst float speed = 2.0;\nconst float decay = 2.0;\nconst float coeff = 2.5;\n\nvoid main() {\n\tfloat sp = pow(speed, lightBrightness);\n\tfloat dc = pow(decay, -lightBrightness);\n\tfloat s = (sp - dc) / (sp + dc);\n\tvec2 radius = (texCoord.st - vec2(0.5, 0.5)) * vec2(coeff * s);\n\tradius = pow(abs(radius), vec2(4.0));\n\tvec3 bleed = vec3(0.12, 0.14, 0.19);\n\tbleed += (dot(radius, radius) + vec3(0.02, 0.03, 0.05)) * vec3(0.14, 0.18, 0.2);\n\n\tvec4 color = texture2D(tex, texCoord);\n\tcolor.rgb += pow(bleed, pow(vec3(lightBrightness), vec3(-0.5)));\n\n\tvec4 reflection = texture2D(tex, texCoord - reflectionDistance);\n\tcolor.rgb += reflection.rgb * reflectionBrightness;\n\tcolor.a = 1.0;\n\tgl_FragColor = color;\n}\n", "ags001.shader/ags001.fs": "varying vec2 texCoord;\nuniform sampler2D tex;\nuniform vec2 texSize;\n\nvoid main() {\n\tvec4 color = texture2D(tex, texCoord);\n\tvec3 arrayX[3];\n\tarrayX[0] = vec3(0.2, 0.2, 1.0);\n\tarrayX[1] = vec3(0.2, 1.0, 0.2);\n\tarrayX[2] = vec3(1.0, 0.2, 0.2);\n\tvec3 arrayY[4];\n\tarrayY[0] = vec3(1.0, 1.0, 1.0);\n\tarrayY[1] = vec3(1.0, 1.0, 1.0);\n\tarrayY[2] = vec3(1.0, 1.0, 1.0);\n\tarrayY[3] = vec3(0.9, 0.9, 0.9);\n\tcolor.rgb = pow(color.rgb, vec3(1.6, 1.6, 1.6));\n\tcolor.rgb *= arrayX[int(mod(texCoord.s * texSize.x * 3.0, 3.0))];\n\tcolor.rgb *= arrayY[int(mod(texCoord.t * texSize.y * 4.0, 4.0))];\n\tcolor.a = 0.8;\n\tgl_FragColor = color;\n}\n", "ags001.shader/manifest.ini": "[shader]\nname=AGS-001\nauthor=endrift\ndescription=A pristine recreation of the illuminated Game Boy Advance SP\npasses=2\n\n[pass.0]\nfragmentShader=ags001.fs\nblend=1\nwidth=-3\nheight=-4\n\n[pass.1]\nfragmentShader=ags001-light.fs\nwidth=-3\nheight=-4\n\n[pass.1.uniform.lightBrightness]\ntype=float\ndefault=1\nreadableName=Light brightness\n\n[pass.1.uniform.reflectionBrightness]\ntype=float\ndefault=0.07\nreadableName=Reflection brightness\n\n[pass.1.uniform.reflectionDistance]\ntype=float2\ndefault[0]=0\ndefault[1]=0.025\nreadableName=Reflection distance\n", "gba-color.shader/gba-color.fs": "varying vec2 texCoord;\nuniform sampler2D tex;\nuniform vec2 texSize;\n\nuniform float darken_screen;\nconst float target_gamma = 2.2;\nconst float display_gamma = 2.5;\nconst float sat = 1.0;\nconst float lum = 0.99;\nconst float contrast = 1.0;\nconst vec3 bl = vec3(0.0, 0.0, 0.0);\nconst vec3 r = vec3(0.84, 0.09, 0.15);\nconst vec3 g = vec3(0.18, 0.67, 0.10);\nconst vec3 b = vec3(0.0, 0.26, 0.73);\n\nvoid main() {\n\tvec4 screen = pow(texture2D(tex, texCoord), vec4(target_gamma + darken_screen)).rgba;\n\tvec4 avglum = vec4(0.5);\n\tscreen = mix(screen, avglum, (1.0 - contrast));\n \n\tmat4 color = mat4(\tr.r,\tr.g,\tr.b,\t0.0,\n\t\t\t\tg.r,\tg.g,\tg.b,\t0.0,\n\t\t\t\tb.r,\tb.g,\tb.b,\t0.0,\n\t\t\t\tbl.r,\tbl.g,\tbl.b,\t1.0);\n\t\t\t  \n\tmat4 adjust = mat4(\t(1.0 - sat) * 0.3086 + sat,\t(1.0 - sat) * 0.3086,\t\t(1.0 - sat) * 0.3086,\t\t1.0,\n\t\t\t\t(1.0 - sat) * 0.6094,\t\t(1.0 - sat) * 0.6094 + sat,\t(1.0 - sat) * 0.6094,\t\t1.0,\n\t\t\t\t(1.0 - sat) * 0.0820,\t\t(1.0 - sat) * 0.0820,\t\t(1.0 - sat) * 0.0820 + sat,\t1.0,\n\t\t\t\t0.0,\t\t\t\t0.0,\t\t\t\t0.0,\t\t\t\t1.0);\n\tcolor *= adjust;\n\tscreen = clamp(screen * lum, 0.0, 1.0);\n\tscreen = color * screen;\n\tgl_FragColor = pow(screen, vec4(1.0 / display_gamma + (darken_screen * 0.125)));\n}\n", "gba-color.shader/manifest.ini": "[shader]\nname=GBA Color\nauthor=Pokefan531 and hunterk\ndescription=Modifies the color output to simulate the GBA LCD characteristics.\npasses=1\n\n[pass.0]\nfragmentShader=gba-color.fs\nblend=1\nwidth=-1\nheight=-1\n\n[pass.0.uniform.darken_screen]\ntype=float\ndefault=0.5\nreadableName=Darken Screen\n", "lcd.shader/lcd.fs": "/*\n   LCD Shader\n\n   Copyright (C) 2017 Dominus Iniquitatis - zerosaiko@gmail.com\n\n   Permission is hereby granted, free of charge, to any person obtaining a copy\n   of this software and associated documentation files (the \"Software\"), to deal\n   in the Software without restriction, including without limitation the rights\n   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n   copies of the Software, and to permit persons to whom the Software is\n   furnished to do so, subject to the following conditions:\n   The above copyright notice and this permission notice shall be included in\n   all copies or substantial portions of the Software.\n   THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\n   THE SOFTWARE.\n*/\n\nuniform sampler2D tex;\nuniform vec2 texSize;\nvarying vec2 texCoord;\n\nuniform float boundBrightness;\n\nvoid main()\n{\n\tvec4 color = texture2D(tex, texCoord);\n\n\tif (int(mod(texCoord.s * texSize.x * 3.0, 3.0)) == 0 ||\n\t\tint(mod(texCoord.t * texSize.y * 3.0, 3.0)) == 0)\n\t{\n\t\tcolor.rgb *= vec3(1.0, 1.0, 1.0) * boundBrightness;\n\t}\n\n\tgl_FragColor = color;\n}\n", "lcd.shader/manifest.ini": "[shader]\nname=LCD\nauthor=Dominus Iniquitatis\ndescription=Simple LCD emulation.\npasses=1\n\n[pass.0]\nfragmentShader=lcd.fs\nblend=1\nwidth=-3\nheight=-3\n\n[pass.0.uniform.boundBrightness]\ntype=float\nreadableName=Bound brightness\ndefault=0.9\nmin=0.0\nmax=1.0\n", "motion_blur.shader/manifest.ini": "[shader]\nname=Motion Blur\nauthor=Dominus Iniquitatis\ndescription=Simple motion blur.\npasses=1\n\n[pass.0]\nfragmentShader=motion_blur.fs\nblend=1\nwidth=-1\nheight=-1\n\n[pass.0.uniform.amount]\ntype=float\nreadableName=Amount\ndefault=0.3\nmin=0.0\nmax=1.0\n", "motion_blur.shader/motion_blur.fs": "/*\n   Motion Blur Shader\n\n   Copyright (C) 2017 Dominus Iniquitatis - zerosaiko@gmail.com\n\n   Permission is hereby granted, free of charge, to any person obtaining a copy\n   of this software and associated documentation files (the \"Software\"), to deal\n   in the Software without restriction, including without limitation the rights\n   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n   copies of the Software, and to permit persons to whom the Software is\n   furnished to do so, subject to the following conditions:\n   The above copyright notice and this permission notice shall be included in\n   all copies or substantial portions of the Software.\n   THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\n   THE SOFTWARE.\n*/\n\nuniform sampler2D tex;\nuniform vec2 texSize;\nvarying vec2 texCoord;\n\nuniform float amount;\n\nvoid main()\n{\n\tvec4 color = texture2D(tex, texCoord);\n\tcolor.a = 1.0 - amount;\n\n\tgl_FragColor = color;\n}\n", "scale2x.shader/manifest.ini": "[shader]\nname=Scale2x\nauthor=singron\ndescription=AdvanceMAME's Scale2x algorithm\npasses=1\n\n[pass.0]\nfragmentShader=scale2x.fs\nblend=1\nwidth=-2\nheight=-2\n", "scale2x.shader/scale2x.fs": "/* Shader implementation of Scale2x is adapted from https://gist.github.com/singron/3161079 */\nvarying vec2 texCoord;\nuniform sampler2D tex;\nuniform vec2 texSize;\n\nvoid main() {\n    // o = offset, the width of a pixel\n    vec2 o = 1.0 / texSize;\n\n    // texel arrangement\n    // A B C\n    // D E F\n    // G H I\n    vec4 B = texture2D(tex, texCoord + vec2(  0.0,  o.y));\n    vec4 D = texture2D(tex, texCoord + vec2( -o.x,  0.0));\n    vec4 E = texture2D(tex, texCoord + vec2(  0.0,  0.0));\n    vec4 F = texture2D(tex, texCoord + vec2(  o.x,  0.0));\n    vec4 H = texture2D(tex, texCoord + vec2(  0.0, -o.y));\n    vec2 p = texCoord * texSize;\n    // p = the texCoord within a pixel [0...1]\n    p = fract(p);\n\tif (p.x > .5) {\n\t\tif (p.y > .5) {\n\t\t\t// Top Right\n\t\t\tgl_FragColor = B == F && B != D && F != H ? F : E;\n\t\t} else {\n\t\t\t// Bottom Right\n\t\t\tgl_FragColor = H == F && D != H && B != F ? F : E;\n\t\t}\n\t} else {\n\t\tif (p.y > .5) {\n\t\t\t// Top Left\n\t\t\tgl_FragColor = D == B && B != F && D != H ? D : E;\n\t\t} else {\n\t\t\t// Bottom Left\n\t\t\tgl_FragColor = D == H && D != B && H != F ? D : E;\n\t\t}\n\t}\n}\n", "scale4x.shader/manifest.ini": "[shader]\nname=Scale4x\nauthor=singron, endrift\ndescription=AdvanceMAME's Scale4x algorithm\npasses=1\n\n[pass.0]\nfragmentShader=scale4x.fs\nblend=1\nwidth=-4\nheight=-4\n", "scale4x.shader/scale4x.fs": "/* Shader implementation of Scale2x is adapted from https://gist.github.com/singron/3161079 */\nvarying vec2 texCoord;\nuniform sampler2D tex;\nuniform vec2 texSize;\n\nvec4 scale2x(vec4 pixels[5], vec2 p) {\n    // texel arrangement\n    // x 0 x\n    // 1 2 3\n    // x 4 x\n    // p = the texCoord within a pixel [0...1]\n    p = fract(p);\n\tif (p.x > .5) {\n\t\tif (p.y > .5) {\n\t\t\t// Top Right\n\t\t\treturn pixels[0] == pixels[3] && pixels[0] != pixels[1] && pixels[3] != pixels[4] ? pixels[3] : pixels[2];\n\t\t} else {\n\t\t\t// Bottom Right\n\t\t\treturn pixels[4] == pixels[3] && pixels[1] != pixels[4] && pixels[0] != pixels[3] ? pixels[3] : pixels[2];\n\t\t}\n\t} else {\n\t\tif (p.y > .5) {\n\t\t\t// Top Left\n\t\t\treturn pixels[1] == pixels[0] && pixels[0] != pixels[3] && pixels[1] != pixels[4] ? pixels[1] : pixels[2];\n\t\t} else {\n\t\t\t// Bottom Left\n\t\t\treturn pixels[1] == pixels[4] && pixels[1] != pixels[0] && pixels[4] != pixels[3] ? pixels[1] : pixels[2];\n\t\t}\n\t}\n}\n\nvec4 scaleNeighborhood(vec2 p, vec2 x, vec2 o) {\n\tvec4 neighborhood[5];\n    neighborhood[0] = texture2D(tex, texCoord + x + vec2( 0.0,  o.y));\n    neighborhood[1] = texture2D(tex, texCoord + x + vec2(-o.x,  0.0));\n    neighborhood[2] = texture2D(tex, texCoord + x + vec2( 0.0,  0.0));\n    neighborhood[3] = texture2D(tex, texCoord + x + vec2( o.x,  0.0));\n    neighborhood[4] = texture2D(tex, texCoord + x + vec2( 0.0, -o.y));\n\treturn scale2x(neighborhood, p + x * texSize);\n}\n\nvoid main() {\n    // o = offset, the width of a pixel\n    vec2 o = 1.0 / texSize;\n\n    vec2 p = texCoord * texSize;\n\tvec4 pixels[5];\n\tpixels[0] = scaleNeighborhood(p, vec2(       0.0,  o.y / 2.0), o);\n\tpixels[1] = scaleNeighborhood(p, vec2(-o.x / 2.0,        0.0), o);\n\tpixels[2] = scaleNeighborhood(p, vec2(       0.0,        0.0), o);\n\tpixels[3] = scaleNeighborhood(p, vec2( o.x / 2.0,        0.0), o);\n\tpixels[4] = scaleNeighborhood(p, vec2(       0.0, -o.y / 2.0), o);\n\tgl_FragColor = scale2x(pixels, p * 2.0);\n}\n", "scanlines.shader/manifest.ini": "[shader]\nname=Scanlines\nauthor=Dominus Iniquitatis\ndescription=Simple scanlines.\npasses=1\n\n[pass.0]\nfragmentShader=scanlines.fs\nblend=1\nwidth=-2\nheight=-2\n\n[pass.0.uniform.lineBrightness]\ntype=float\nreadableName=Line brightness\ndefault=0.5\nmin=0.0\nmax=1.0\n", "scanlines.shader/scanlines.fs": "/*\n   Scanlines Shader\n\n   Copyright (C) 2017 Dominus Iniquitatis - zerosaiko@gmail.com\n\n   Permission is hereby granted, free of charge, to any person obtaining a copy\n   of this software and associated documentation files (the \"Software\"), to deal\n   in the Software without restriction, including without limitation the rights\n   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n   copies of the Software, and to permit persons to whom the Software is\n   furnished to do so, subject to the following conditions:\n   The above copyright notice and this permission notice shall be included in\n   all copies or substantial portions of the Software.\n   THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\n   THE SOFTWARE.\n*/\n\nuniform sampler2D tex;\nuniform vec2 texSize;\nvarying vec2 texCoord;\n\nuniform float lineBrightness;\n\nvoid main()\n{\n\tvec4 color = texture2D(tex, texCoord);\n\n\tif (int(mod(texCoord.t * texSize.y * 2.0, 2.0)) == 0)\n\t{\n\t\tcolor.rgb *= vec3(1.0, 1.0, 1.0) * lineBrightness;\n\t}\n\n\tgl_FragColor = color;\n}\n", "soften.shader/manifest.ini": "[shader]\nname=Soften\nauthor=Dominus Iniquitatis\ndescription=Soft image blurring.\npasses=1\n\n[pass.0]\nfragmentShader=soften.fs\nblend=1\nwidth=-1\nheight=-1\n\n[pass.0.uniform.amount]\ntype=float\nreadableName=Amount\ndefault=0.5\nmin=0.0\nmax=1.0\n", "soften.shader/soften.fs": "/*\n   Soften Shader\n\n   Copyright (C) 2017 Dominus Iniquitatis - zerosaiko@gmail.com\n\n   Permission is hereby granted, free of charge, to any person obtaining a copy\n   of this software and associated documentation files (the \"Software\"), to deal\n   in the Software without restriction, including without limitation the rights\n   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n   copies of the Software, and to permit persons to whom the Software is\n   furnished to do so, subject to the following conditions:\n   The above copyright notice and this permission notice shall be included in\n   all copies or substantial portions of the Software.\n   THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\n   THE SOFTWARE.\n*/\n\nuniform sampler2D tex;\nuniform vec2 texSize;\nvarying vec2 texCoord;\n\nuniform float amount;\n\nvec2 GetTexelSize()\n{\n\treturn vec2(1.0 / texSize.x, 1.0 / texSize.y);\n}\n\nvoid main()\n{\n\tvec4 color = texture2D(tex, texCoord);\n\n\tvec4 northColor = texture2D(tex, texCoord + vec2(0.0, GetTexelSize().y));\n\tvec4 southColor = texture2D(tex, texCoord - vec2(0.0, GetTexelSize().y));\n\tvec4 eastColor = texture2D(tex, texCoord + vec2(GetTexelSize().x, 0.0));\n\tvec4 westColor = texture2D(tex, texCoord - vec2(GetTexelSize().x, 0.0));\n\n\tif (abs(length(color) - length(northColor)) > 0.0)\n\t{\n\t\tcolor = mix(color, northColor, amount / 4.0);\n\t}\n\n\tif (abs(length(color) - length(southColor)) > 0.0)\n\t{\n\t\tcolor = mix(color, southColor, amount / 4.0);\n\t}\n\n\tif (abs(length(color) - length(eastColor)) > 0.0)\n\t{\n\t\tcolor = mix(color, eastColor, amount / 4.0);\n\t}\n\n\tif (abs(length(color) - length(westColor)) > 0.0)\n\t{\n\t\tcolor = mix(color, westColor, amount / 4.0);\n\t}\n\n\tgl_FragColor = color;\n}\n", "tv-mode.shader/manifest.ini": "[shader]\nname=TV Mode\nauthor=Dominus Iniquitatis\ndescription=Scanlines along with a subtle blurring.\npasses=1\n\n[pass.0]\nfragmentShader=tv.fs\nblend=1\nwidth=-2\nheight=-2\n\n[pass.0.uniform.lineBrightness]\ntype=float\nreadableName=Line brightness\ndefault=0.75\nmin=0.0\nmax=1.0\n\n[pass.0.uniform.blurring]\ntype=float\nreadableName=Blurring\ndefault=1.0\nmin=0.0\nmax=1.0\n", "tv-mode.shader/tv.fs": "/*\n   TV Mode Shader\n\n   Copyright (C) 2022 Dominus Iniquitatis - zerosaiko@gmail.com\n\n   Permission is hereby granted, free of charge, to any person obtaining a copy\n   of this software and associated documentation files (the \"Software\"), to deal\n   in the Software without restriction, including without limitation the rights\n   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n   copies of the Software, and to permit persons to whom the Software is\n   furnished to do so, subject to the following conditions:\n   The above copyright notice and this permission notice shall be included in\n   all copies or substantial portions of the Software.\n   THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\n   THE SOFTWARE.\n*/\n\nuniform sampler2D tex;\nuniform vec2 texSize;\nvarying vec2 texCoord;\n\nuniform float lineBrightness;\nuniform float blurring;\n\nvoid main()\n{\n    vec4 c = texture2D(tex, texCoord);\n    vec4 n = texture2D(tex, texCoord + vec2(1.0 / texSize.x * 0.5, 0.0));\n\n    vec4 color = mix(c, (c + n) / 2.0, blurring);\n    color.a = c.a;\n\n\tif (int(mod(texCoord.t * texSize.y * 2.0, 2.0)) == 0)\n\t{\n\t\tcolor.rgb *= lineBrightness;\n\t}\n\n\tgl_FragColor = color;\n}\n", "vba_pixelate.shader/manifest.ini": "[shader]\nname=VBA Pixelate\nauthor=Dominus Iniquitatis\ndescription=VisualBoyAdvance-style pixelation.\npasses=1\n\n[pass.0]\nfragmentShader=vba_pixelate.fs\nblend=1\nwidth=-2\nheight=-2\n\n[pass.0.uniform.boundBrightness]\ntype=float\nreadableName=Bound brightness\ndefault=0.5\nmin=0.0\nmax=1.0\n", "vba_pixelate.shader/vba_pixelate.fs": "/*\n   VBA Pixelate Shader\n\n   Copyright (C) 2017 Dominus Iniquitatis - zerosaiko@gmail.com\n\n   Permission is hereby granted, free of charge, to any person obtaining a copy\n   of this software and associated documentation files (the \"Software\"), to deal\n   in the Software without restriction, including without limitation the rights\n   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n   copies of the Software, and to permit persons to whom the Software is\n   furnished to do so, subject to the following conditions:\n   The above copyright notice and this permission notice shall be included in\n   all copies or substantial portions of the Software.\n   THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\n   THE SOFTWARE.\n*/\n\nuniform sampler2D tex;\nuniform vec2 texSize;\nvarying vec2 texCoord;\n\nuniform float boundBrightness;\n\nvoid main()\n{\n\tvec4 color = texture2D(tex, texCoord);\n\n\tif (int(mod(texCoord.s * texSize.x * 2.0, 2.0)) == 0 ||\n\t\tint(mod(texCoord.t * texSize.y * 2.0, 2.0)) == 0)\n\t{\n\t\tcolor.rgb *= vec3(1.0, 1.0, 1.0) * boundBrightness;\n\t}\n\n\tgl_FragColor = color;\n}\n", "vignette.shader/manifest.ini": "[shader]\nname=Vignette\nauthor=Dominus Iniquitatis\ndescription=Configurable vignette effect.\npasses=1\n\n[pass.0]\nfragmentShader=vignette.fs\nblend=1\nwidth=-1\nheight=-1\n\n[pass.0.uniform.intensity]\ntype=float\nreadableName=Intensity\ndefault=1.0\nmin=0.0\nmax=1.0\n", "vignette.shader/vignette.fs": "/*\n   Vignette Shader\n\n   Copyright (C) 2017 Dominus Iniquitatis - zerosaiko@gmail.com\n\n   Permission is hereby granted, free of charge, to any person obtaining a copy\n   of this software and associated documentation files (the \"Software\"), to deal\n   in the Software without restriction, including without limitation the rights\n   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n   copies of the Software, and to permit persons to whom the Software is\n   furnished to do so, subject to the following conditions:\n   The above copyright notice and this permission notice shall be included in\n   all copies or substantial portions of the Software.\n   THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\n   THE SOFTWARE.\n*/\n\nuniform sampler2D tex;\nuniform vec2 texSize;\nvarying vec2 texCoord;\n\nuniform float intensity;\n\nvoid main()\n{\n\tvec4 color = texture2D(tex, texCoord);\n\tcolor = mix(color, vec4(0.0, 0.0, 0.0, 1.0), length(texCoord - 0.5) * intensity);\n\n\tgl_FragColor = color;\n}\n", "wiiu.shader/manifest.ini": "[shader]\nname=Wii U\nauthor=Prof. 9\ndescription=Uses the color palette from the Wii U Virtual Console. Enable bilinear filtering to further mimic Wii U output.\npasses=1\n\n[pass.0]\nfragmentShader=wiiu.fs\nblend=1\nwidth=-4\nheight=-4\n", "wiiu.shader/wiiu.fs": "varying vec2 texCoord;\nuniform sampler2D tex;\nuniform vec2 texSize;\n\nvoid main() {\n\tfloat scale[32];\n\tscale[ 0] =   0.0/255.0; scale[ 1] = 6.0/255.0;\n\tscale[ 2] =  12.0/255.0; scale[ 3] = 18.0/255.0;\n\tscale[ 4] =  24.0/255.0; scale[ 5] = 31.0/255.0;\n\tscale[ 6] =  37.0/255.0; scale[ 7] = 43.0/255.0;\n\tscale[ 8] =  49.0/255.0; scale[ 9] = 55.0/255.0;\n\tscale[10] =  61.0/255.0; scale[11] = 67.0/255.0;\n\tscale[12] =  73.0/255.0; scale[13] = 79.0/255.0;\n\tscale[14] =  86.0/255.0; scale[15] = 92.0/255.0;\n\tscale[16] =  98.0/255.0; scale[17] = 104.0/255.0;\n\tscale[18] = 111.0/255.0; scale[19] = 117.0/255.0;\n\tscale[20] = 123.0/255.0; scale[21] = 129.0/255.0;\n\tscale[22] = 135.0/255.0; scale[23] = 141.0/255.0;\n\tscale[24] = 148.0/255.0; scale[25] = 154.0/255.0;\n\tscale[26] = 159.0/255.0; scale[27] = 166.0/255.0;\n\tscale[28] = 172.0/255.0; scale[29] = 178.0/255.0;\n\tscale[30] = 184.0/255.0; scale[31] = 191.0/255.0;\n\t\n\tvec4 color = texture2D(tex, texCoord);\n\tcolor.r = scale[int(floor(color.r * 31.0 + 0.5))];\n\tcolor.g = scale[int(floor(color.g * 31.0 + 0.5))];\n\tcolor.b = scale[int(floor(color.b * 31.0 + 0.5))];\n\tgl_FragColor = color;\n}\n"};
(() => {
"use strict";
const playerUrl = document.currentScript.src;
const modules = {};
// vendor/mgba.options.js
modules["vendor/mgba.options.js"] = (() => {
const DEFAULT_MGBA_OPTIONS = {
    system: 'auto',
    gbModel: 'auto',
    idleOptimization: 'remove',
    skipBios: true,
    allowOpposingDirections: false,
    renderFilter: 'pixelated',
    aspect: 'native',
    interframeBlending: false,
    volume: 1.0,
    gamepads: true,
    logLevel: 'error',
    escMenu: true,
};
/** Platform ids consumed by `mgbawasm_setup()` (mPLATFORM_* in core/core.h). */
const MGBA_PLATFORM_IDS = {
    auto: -1,
    gba: 0,
    gb: 1,
};
/** Values mGBA's `gb.model` config key takes; `auto` means "leave unset". */
const MGBA_GB_MODEL_VALUES = {
    auto: null,
    dmg: 'DMG',
    sgb: 'SGB',
    cgb: 'CGB',
    agb: 'AGB',
};
const MGBA_LOG_LEVEL_IDS = {
    off: 0,
    error: 1,
    debug: 2,
};
const MGBA_OPTION_GROUPS = [
    {
        id: 'video',
        label: 'Video',
        options: [
            {
                key: 'renderFilter',
                label: 'Image filtering',
                description: 'Scaling filter applied when the picture is stretched to the canvas. Pixelated keeps pixel art crisp; smooth softens it.',
                type: 'enum',
                default: DEFAULT_MGBA_OPTIONS.renderFilter,
                values: [
                    { value: 'pixelated', label: 'Pixelated' },
                    { value: 'smooth', label: 'Smooth' },
                ],
            },
            {
                key: 'aspect',
                label: 'Aspect ratio',
                description: 'Native is square pixels, as the handheld LCDs had them: 3:2 on GBA, 10:9 on Game Boy. 4:3 stretches the picture into a TV-shaped frame.',
                type: 'enum',
                default: DEFAULT_MGBA_OPTIONS.aspect,
                values: [
                    { value: 'native', label: 'Native' },
                    { value: '4:3', label: '4:3' },
                ],
            },
            {
                key: 'interframeBlending',
                label: 'Interframe blending',
                description: 'Blend each frame with the previous one, approximating the ghosting of the original unlit LCD. Restores transparency effects that games drew by flickering sprites every other frame.',
                type: 'boolean',
                default: DEFAULT_MGBA_OPTIONS.interframeBlending,
            },
        ],
    },
    {
        id: 'audio',
        label: 'Audio',
        options: [
            {
                key: 'volume',
                label: 'Volume',
                description: 'Master audio volume.',
                type: 'number',
                default: DEFAULT_MGBA_OPTIONS.volume,
                values: [
                    { value: 0, label: 'Mute' },
                    { value: 0.25, label: '25%' },
                    { value: 0.5, label: '50%' },
                    { value: 0.75, label: '75%' },
                    { value: 1, label: '100%' },
                ],
                range: { minimum: 0, maximum: 1 },
            },
        ],
    },
    {
        id: 'emulation',
        label: 'Emulation',
        options: [
            {
                key: 'system',
                label: 'System',
                description: 'Which core boots the ROM. Auto sniffs the image, which is right for every well-formed dump; force it for headerless or mislabelled files.',
                type: 'enum',
                default: DEFAULT_MGBA_OPTIONS.system,
                requiresReset: true,
                values: [
                    { value: 'auto', label: 'Auto' },
                    { value: 'gba', label: 'GBA' },
                    { value: 'gb', label: 'Game Boy' },
                ],
            },
            {
                key: 'gbModel',
                label: 'Game Boy model',
                description: 'Hardware the Game Boy core emulates. Auto follows the cartridge header. Ignored when a GBA ROM is loaded.',
                type: 'enum',
                default: DEFAULT_MGBA_OPTIONS.gbModel,
                requiresReset: true,
                values: [
                    { value: 'auto', label: 'Auto' },
                    { value: 'dmg', label: 'DMG' },
                    { value: 'sgb', label: 'Super GB' },
                    { value: 'cgb', label: 'Color' },
                    { value: 'agb', label: 'GBA' },
                ],
            },
            {
                key: 'idleOptimization',
                label: 'Idle loops',
                description: 'How the GBA core treats the busy-wait loops games spin in. Remove skips them and is where nearly all of the speed comes from; ignore emulates them cycle for cycle.',
                type: 'enum',
                default: DEFAULT_MGBA_OPTIONS.idleOptimization,
                values: [
                    { value: 'remove', label: 'Remove' },
                    { value: 'detect', label: 'Detect' },
                    { value: 'ignore', label: 'Ignore' },
                ],
            },
            {
                key: 'skipBios',
                label: 'Skip BIOS intro',
                description: 'Jump straight into the game instead of playing the boot animation. Forced on when no BIOS image was supplied, since the built-in HLE BIOS has no intro.',
                type: 'boolean',
                default: DEFAULT_MGBA_OPTIONS.skipBios,
                requiresReset: true,
            },
        ],
    },
    {
        id: 'controllers',
        label: 'Controllers',
        options: [
            {
                key: 'allowOpposingDirections',
                label: 'Opposing directions',
                description: 'Let the D-pad report left+right (or up+down) at once. Real hardware cannot, and a few games misbehave when it happens.',
                type: 'boolean',
                default: DEFAULT_MGBA_OPTIONS.allowOpposingDirections,
            },
            {
                key: 'gamepads',
                label: 'Gamepads',
                description: 'Poll connected gamepads (standard mapping) each frame.',
                type: 'boolean',
                default: DEFAULT_MGBA_OPTIONS.gamepads,
            },
        ],
    },
    {
        id: 'debug',
        label: 'Debug',
        options: [
            {
                key: 'logLevel',
                label: 'Core logging',
                description: 'Core messages printed to the browser console: errors and warnings, or also its informational ones.',
                type: 'enum',
                default: DEFAULT_MGBA_OPTIONS.logLevel,
                values: [
                    { value: 'off', label: 'Off' },
                    { value: 'error', label: 'Errors' },
                    { value: 'debug', label: 'Debug' },
                ],
            },
        ],
    },
];
/** Flat view of every runtime-tweakable option across all groups. */
const MGBA_ENGINE_OPTIONS = MGBA_OPTION_GROUPS.flatMap((group) => group.options);
const OPTION_BY_KEY = new Map(MGBA_ENGINE_OPTIONS.map((option) => [option.key, option]));
function mgbaOption(key) {
    return OPTION_BY_KEY.get(key);
}
/**
 * Coerces a host- or storage-supplied value to what the option accepts,
 * returning `undefined` when it is not a value the option can take. Numbers
 * outside a `range` are clamped rather than rejected; enums are exact.
 */
function coerceOptionValue(option, value) {
    if (option.type === 'boolean') {
        return typeof value === 'boolean' ? value : undefined;
    }
    if (option.type === 'enum') {
        const next = String(value);
        return option.values.some((choice) => choice.value === next) ? next : undefined;
    }
    const next = typeof value === 'number' ? value : Number(value);
    if (!Number.isFinite(next))
        return undefined;
    if (option.range) {
        return Math.min(option.range.maximum, Math.max(option.range.minimum, next));
    }
    return option.values.some((choice) => choice.value === next) ? next : undefined;
}
/**
 * Projects the catalog onto the shape `@wasm-gaming/engine-specs` (>=0.2.5)
 * feeds its `esc-menu` component.
 *
 * The menu lives in the demo shell now, not in this package: the shell renders
 * the rows and emits `option-change`, and the host writes the value back
 * through `engine.config`. Since the component only draws chips for `boolean`
 * and `enum`, numeric options are handed over as an enum of their menu choices
 * — the numbers survive, because the chips compare values with `===`.
 *
 * Pass the running engine's `config.values()` so the menu opens on what the
 * emulator is actually set to rather than on this package's defaults.
 */
function toEscMenuGroups(values = {}) {
    return MGBA_OPTION_GROUPS.map((group) => ({
        id: group.id,
        label: group.label,
        options: group.options.map((option) => ({
            key: option.key,
            label: option.label,
            description: option.description,
            type: option.type === 'boolean' ? 'boolean' : 'enum',
            value: values[option.key] ?? option.default,
            ...(option.type === 'boolean' ? {} : { values: option.values }),
            ...(option.requiresReset ? { requiresReset: true } : {}),
        })),
    }));
}
// -------------------------------------------------------------- schema
function schemaForOption(option) {
    if (option.type === 'boolean') {
        return { type: 'boolean', default: option.default, description: option.description };
    }
    if (option.type === 'enum') {
        return {
            type: 'string',
            enum: option.values.map((choice) => choice.value),
            default: option.default,
            description: option.description,
        };
    }
    return {
        type: option.integer ? 'integer' : 'number',
        default: option.default,
        ...(option.range
            ? { minimum: option.range.minimum, maximum: option.range.maximum }
            : { enum: option.values.map((choice) => choice.value) }),
        description: option.description,
    };
}
const MGBA_OPTIONS_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        ...Object.fromEntries(MGBA_ENGINE_OPTIONS.map((option) => [option.key, schemaForOption(option)])),
        escMenu: {
            type: 'boolean',
            default: true,
            description: "Show the demo shell's in-game settings menu when the player presses Escape.",
        },
    },
};
//# sourceMappingURL=mgba.options.js.map
return { DEFAULT_MGBA_OPTIONS, MGBA_PLATFORM_IDS, MGBA_GB_MODEL_VALUES, MGBA_LOG_LEVEL_IDS, MGBA_OPTION_GROUPS, MGBA_ENGINE_OPTIONS, mgbaOption, coerceOptionValue, toEscMenuGroups, MGBA_OPTIONS_SCHEMA };
})();
// vendor/mgba.manifest.js
modules["vendor/mgba.manifest.js"] = (() => {
const { MGBA_OPTIONS_SCHEMA } = modules["vendor/mgba.options.js"];
const manifest = {
    id: 'mgba',
    version: '0.1.0',
    name: 'mGBA (WebAssembly)',
    description: 'mGBA — the accuracy-focused Game Boy Advance emulator, which also runs Game Boy and Game Boy Color — compiled to WebAssembly. Loads .gba/.gb/.gbc cartridge images; the GBA BIOS is optional, since mGBA ships a high-level replacement.',
    artifacts: {
        wasm: 'mgba/mgba.wasm',
        js: 'mgba/mgba.js',
    },
    assets: [
        {
            key: 'rom',
            mountPath: '/rom.gba',
            required: true,
            accept: ['.gba', '.gb', '.gbc', '.sgb'],
            description: 'Game Boy Advance, Game Boy or Game Boy Color cartridge image. The right core is picked from the image itself, so the extension only has to be one mGBA recognizes.',
        },
        {
            key: 'bios',
            mountPath: '/bios.bin',
            required: false,
            accept: ['.bin', '.rom'],
            description: 'Optional GBA BIOS dump (16 KiB). mGBA has a high-level replacement that runs virtually everything, so this is only needed for the boot animation and the handful of titles that read the BIOS directly.',
            validate: { bytes: 16384 },
        },
    ],
    input: 'mgba',
    // The GBA LCD. The Game Boy cores render 160x144 into the same buffer, and
    // the SDK follows `currentVideoSize()` rather than these numbers at runtime.
    video: { baseWidth: 240, baseHeight: 160, aspect: '3:2' },
    options: MGBA_OPTIONS_SCHEMA,
    // coreSelectable: one package, two cores (GBA and GB) — the host may offer
    // the choice, and `options.system` is where it lands.
    capabilities: { saveStates: true, sram: true, coreSelectable: true },
};
const moduleDefault = manifest;
//# sourceMappingURL=mgba.manifest.js.map
return { manifest, default: moduleDefault };
})();
// vendor/mgba.config.js
modules["vendor/mgba.config.js"] = (() => {
const { coerceOptionValue, mgbaOption, MGBA_ENGINE_OPTIONS } = modules["vendor/mgba.options.js"];
function bindConfig(state, appliers) {
    const applierFor = (key) => appliers[key];
    const supports = (key) => Boolean(mgbaOption(key)) && applierFor(key) !== undefined;
    const read = (key) => mgbaOption(key) ? state[key] : undefined;
    const write = (key, value) => {
        const option = mgbaOption(key);
        const apply = applierFor(key);
        if (!option || !apply)
            return false;
        const next = coerceOptionValue(option, value);
        if (next === undefined)
            return false;
        state[key] = next;
        apply(next);
        return true;
    };
    return {
        supports,
        read,
        write,
        values() {
            const snapshot = {};
            for (const option of MGBA_ENGINE_OPTIONS) {
                if (supports(option.key))
                    snapshot[option.key] = state[option.key];
            }
            return snapshot;
        },
        restoreDefaults() {
            for (const option of MGBA_ENGINE_OPTIONS) {
                write(option.key, option.default);
            }
        },
    };
}
function createSettingsStore(namespace) {
    const storageKey = `mgba:options:${namespace}`;
    // Storage access throws outright in some privacy modes, so every call is
    // guarded — losing persistence must never take the emulator down with it.
    const storage = () => {
        try {
            return typeof localStorage === 'undefined' ? null : localStorage;
        }
        catch {
            return null;
        }
    };
    return {
        load() {
            try {
                const raw = storage()?.getItem(storageKey);
                if (!raw)
                    return {};
                const parsed = JSON.parse(raw);
                if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
                    return {};
                // Anything the catalog no longer recognizes is dropped rather than fed
                // back into the core: this is user-writable storage.
                const values = {};
                for (const [key, value] of Object.entries(parsed)) {
                    const option = mgbaOption(key);
                    if (!option)
                        continue;
                    const coerced = coerceOptionValue(option, value);
                    if (coerced !== undefined)
                        values[key] = coerced;
                }
                return values;
            }
            catch {
                return {};
            }
        },
        save(values) {
            try {
                storage()?.setItem(storageKey, JSON.stringify(values));
            }
            catch {
                // persistence is best-effort
            }
        },
        clear() {
            try {
                storage()?.removeItem(storageKey);
            }
            catch {
                // persistence is best-effort
            }
        },
    };
}
//# sourceMappingURL=mgba.config.js.map
return { bindConfig, createSettingsStore };
})();
// vendor/mgba.zip.js
modules["vendor/mgba.zip.js"] = (() => {
/**
 * A zip reader just large enough to pull a ROM out of an archive.
 *
 * mGBA can read zips when it is built against libzip or minizip, but linking
 * either into an Emscripten build means vendoring a C dependency for something
 * the platform already does: `DecompressionStream('deflate-raw')` is in every
 * browser this SDK targets and in Node 18+. So the container is parsed here —
 * end-of-central-directory, then the central directory — and the one entry that
 * looks like a ROM is inflated.
 *
 * Deliberately partial: no encryption, no zip64, no multi-disk. Those do not
 * show up around cartridge dumps, and failing loudly beats half-supporting them.
 */
const SIG_EOCD = 0x06054b50;
const SIG_CENTRAL = 0x02014b50;
const SIG_LOCAL = 0x04034b50;
const STORED = 0;
const DEFLATED = 8;
/** A zip always starts with a local file header signature. */
function isZip(bytes) {
    return (bytes.length > 4 &&
        bytes[0] === 0x50 &&
        bytes[1] === 0x4b &&
        bytes[2] === 0x03 &&
        bytes[3] === 0x04);
}
function findEocd(view) {
    // The EOCD is last, but a trailing comment of up to 64 KiB may follow it.
    const min = Math.max(0, view.byteLength - 0x10000 - 22);
    for (let i = view.byteLength - 22; i >= min; i--) {
        if (view.getUint32(i, true) === SIG_EOCD)
            return i;
    }
    return -1;
}
function listEntries(bytes) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const eocd = findEocd(view);
    if (eocd < 0)
        throw new Error('mgba: not a zip archive (no end-of-central-directory record)');
    const count = view.getUint16(eocd + 10, true);
    let offset = view.getUint32(eocd + 16, true);
    const decoder = new TextDecoder();
    const entries = [];
    for (let i = 0; i < count; i++) {
        if (view.getUint32(offset, true) !== SIG_CENTRAL)
            break;
        const nameLength = view.getUint16(offset + 28, true);
        const extraLength = view.getUint16(offset + 30, true);
        const commentLength = view.getUint16(offset + 32, true);
        entries.push({
            name: decoder.decode(bytes.subarray(offset + 46, offset + 46 + nameLength)),
            compression: view.getUint16(offset + 10, true),
            compressedSize: view.getUint32(offset + 20, true),
            uncompressedSize: view.getUint32(offset + 24, true),
            localHeaderOffset: view.getUint32(offset + 42, true),
        });
        offset += 46 + nameLength + extraLength + commentLength;
    }
    return entries;
}
async function readEntry(bytes, entry) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const header = entry.localHeaderOffset;
    if (view.getUint32(header, true) !== SIG_LOCAL) {
        throw new Error(`mgba: corrupt zip entry "${entry.name}"`);
    }
    // The local header repeats the name and extra field with its own lengths,
    // which are the ones that count for locating the data.
    const nameLength = view.getUint16(header + 26, true);
    const extraLength = view.getUint16(header + 28, true);
    const start = header + 30 + nameLength + extraLength;
    const data = bytes.subarray(start, start + entry.compressedSize);
    if (entry.compression === STORED)
        return data.slice();
    if (entry.compression !== DEFLATED) {
        throw new Error(`mgba: zip entry "${entry.name}" uses an unsupported compression method (${entry.compression})`);
    }
    if (typeof DecompressionStream === 'undefined') {
        throw new Error('mgba: this environment cannot inflate zip entries (no DecompressionStream)');
    }
    const stream = new Blob([data])
        .stream()
        .pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
}
/**
 * Returns the ROM inside a zip, or the input unchanged when it is not one.
 *
 * Cartridge archives are almost always a single ROM plus the odd text file, so
 * the pick is "the first entry with an extension mGBA knows"; if none of them
 * carries a useful extension, the largest entry wins, which is what a ROM is.
 */
async function extractRom(bytes, accept) {
    if (!isZip(bytes))
        return { bytes };
    const entries = listEntries(bytes).filter((entry) => !entry.name.endsWith('/') && entry.uncompressedSize > 0);
    if (!entries.length)
        throw new Error('mgba: the zip archive contains no files');
    const byExtension = entries.find((entry) => accept.some((ext) => entry.name.toLowerCase().endsWith(ext)));
    const chosen = byExtension ??
        entries.reduce((largest, entry) => entry.uncompressedSize > largest.uncompressedSize ? entry : largest);
    return { bytes: await readEntry(bytes, chosen), name: chosen.name };
}
//# sourceMappingURL=mgba.zip.js.map
return { isZip, listEntries, readEntry, extractRom };
})();
// vendor/mgba.sdk.js
modules["vendor/mgba.sdk.js"] = (() => {
const { manifest } = modules["vendor/mgba.manifest.js"];
const { bindConfig, createSettingsStore } = modules["vendor/mgba.config.js"];
const { coerceOptionValue, DEFAULT_MGBA_OPTIONS, MGBA_ENGINE_OPTIONS, MGBA_GB_MODEL_VALUES, MGBA_LOG_LEVEL_IDS, MGBA_PLATFORM_IDS, toEscMenuGroups } = modules["vendor/mgba.options.js"];
const { extractRom } = modules["vendor/mgba.zip.js"];

/** `enum mPlatform` values, as reported by `_mgbawasm_platform()`. */
const PLATFORM_GBA = 0;
const PLATFORM_GB = 1;
/** Numeric ids `mgbawasm_set_idle_optimization()` takes. */
const IDLE_IDS = { ignore: 0, remove: 1, detect: 2 };
/**
 * Bit index of each control, matching `enum GBAKey` in mGBA. The Game Boy core
 * numbers its first eight keys the same way, so one mask drives both; the L/R
 * bits are ignored while a Game Boy ROM is running.
 */
const KEY_BITS = {
    a: 0,
    b: 1,
    select: 2,
    start: 3,
    right: 4,
    left: 5,
    up: 6,
    down: 7,
    r: 8,
    l: 9,
};
/**
 * Default keyboard bindings (KeyboardEvent.code → control). X/Z sit where A/B
 * do on the handheld: A is the right-hand button, B the left one.
 */
const DEFAULT_KEYMAP = {
    'p1.up': 'ArrowUp',
    'p1.down': 'ArrowDown',
    'p1.left': 'ArrowLeft',
    'p1.right': 'ArrowRight',
    'p1.a': 'KeyX',
    'p1.b': 'KeyZ',
    'p1.l': 'KeyA',
    'p1.r': 'KeyS',
    'p1.start': 'Enter',
    'p1.select': 'ShiftRight',
};
/**
 * AudioWorklet processor: an SPSC float ring fed int16 chunks, resampling on
 * the way out.
 *
 * The resampling is here rather than in the SDK because these cores emit at a
 * rate the SDK does not choose and cannot pin: 131072 Hz on Game Boy, and 32768
 * or 65536 Hz on GBA depending on what the running game has written to
 * SOUNDBIAS. A `rate` message retunes the read cursor mid-stream, so a game
 * changing resolution is a ratio change and not a glitch.
 *
 * `consumed` is reported in *source* frames — that is the unit the SDK's pacing
 * arithmetic works in, since that is what the core produces.
 */
const WORKLET_SOURCE = `
class MgbaSink extends AudioWorkletProcessor {
  constructor() {
    super();
    this.cap = 32768; // source frames
    this.buf = new Float32Array(this.cap * 2);
    this.pos = 0; // fractional read cursor, in source frames
    this.w = 0;   // source frames written
    this.ratio = 1;
    this.lastPost = 0;
    this.port.onmessage = (e) => {
      const msg = e.data;
      if (msg && msg.rate) {
        this.ratio = msg.rate / sampleRate;
        return;
      }
      const s = msg; // Int16Array, interleaved stereo
      const frames = s.length >> 1;
      for (let i = 0; i < frames; i++) {
        if (this.w - this.pos >= this.cap) break; // full: drop excess
        const idx = (this.w % this.cap) * 2;
        this.buf[idx] = s[i * 2] / 32768;
        this.buf[idx + 1] = s[i * 2 + 1] / 32768;
        this.w++;
      }
    };
  }
  process(inputs, outputs) {
    const out = outputs[0];
    const L = out[0];
    const R = out[1] || out[0];
    const n = L.length;
    for (let i = 0; i < n; i++) {
      // One source frame must be left past the cursor to interpolate against.
      if (this.pos + 1 < this.w) {
        const base = Math.floor(this.pos);
        const frac = this.pos - base;
        const a = (base % this.cap) * 2;
        const b = ((base + 1) % this.cap) * 2;
        L[i] = this.buf[a] + (this.buf[b] - this.buf[a]) * frac;
        R[i] = this.buf[a + 1] + (this.buf[b + 1] - this.buf[a + 1]) * frac;
        this.pos += this.ratio;
      } else {
        L[i] = 0;
        R[i] = 0;
      }
    }
    const consumed = Math.floor(this.pos);
    if (consumed - this.lastPost >= 1024) {
      this.port.postMessage(consumed);
      this.lastPost = consumed;
    }
    return true;
  }
}
registerProcessor('mgba-sink', MgbaSink);
`;
const scriptLoadCache = new Map();
function loadClassicScriptOnce(src) {
    const cached = scriptLoadCache.get(src);
    if (cached)
        return cached;
    const p = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = src;
        script.async = true;
        script.onload = () => resolve();
        script.onerror = () => reject(new Error(`mgba: failed to load script: ${src}`));
        document.head.appendChild(script);
    });
    scriptLoadCache.set(src, p);
    return p;
}
function toUint8(x) {
    if (x == null)
        return null;
    if (typeof x === 'string')
        return new TextEncoder().encode(x);
    if (x instanceof Uint8Array)
        return x;
    if (x instanceof ArrayBuffer)
        return new Uint8Array(x);
    if (ArrayBuffer.isView(x))
        return new Uint8Array(x.buffer, x.byteOffset, x.byteLength);
    throw new TypeError('mgba: asset must be Uint8Array | ArrayBuffer | string');
}
function resolveCanvas(config) {
    const canvasEl = config.canvasEl;
    if (canvasEl)
        return canvasEl;
    const attachTo = config.attachTo;
    if (attachTo) {
        const existing = attachTo.querySelector('canvas');
        if (existing)
            return existing;
        const created = document.createElement('canvas');
        attachTo.appendChild(created);
        return created;
    }
    throw new Error('mgba: config.canvasEl or config.attachTo is required');
}
async function opfsDir(namespace, create) {
    try {
        const root = await navigator.storage.getDirectory();
        const engineDir = await root.getDirectoryHandle('mgba', { create });
        return await engineDir.getDirectoryHandle(namespace, { create });
    }
    catch {
        return null;
    }
}
/** Copy bytes into the WASM heap; returns the pointer (caller frees). */
function heapAlloc(mod, bytes) {
    const ptr = mod._malloc(bytes.length);
    mod.HEAPU8.set(bytes, ptr);
    return ptr;
}
async function load(config) {
    const { assets, onEvent } = config;
    const emit = (e) => {
        try {
            onEvent?.(e);
        }
        catch {
            // host callback must not break the engine runtime
        }
    };
    const rawRom = toUint8(assets?.rom ?? assets?.data);
    if (!rawRom) {
        throw new Error('mgba: no ROM provided — pass assets.rom (a .gba/.gb/.gbc cartridge image)');
    }
    // Cartridge dumps circulate zipped far more often than not, and this build
    // carries no libzip, so the archive is opened here instead.
    const { bytes: romBytes } = await extractRom(rawRom, ['.gba', '.gb', '.gbc', '.sgb']);
    const biosBytes = toUint8(assets?.bios);
    const namespace = config.storageNamespace ?? 'default';
    const settingsStore = createSettingsStore(namespace);
    const requested = (config.options ?? {});
    // This package's defaults, then the player's persisted menu tweaks, then
    // whatever the host asked for explicitly — a caller-supplied option is a
    // deliberate choice and outranks the last session.
    const opts = { ...DEFAULT_MGBA_OPTIONS };
    // The same object seen by key, which is what the live config writes through:
    // the loop reads `opts` every frame, so a menu change is picked up with no
    // further plumbing.
    const state = opts;
    const persisted = settingsStore.load();
    for (const option of MGBA_ENGINE_OPTIONS) {
        const stored = persisted[option.key];
        if (stored !== undefined)
            state[option.key] = stored;
        const asked = requested[option.key];
        if (asked === undefined)
            continue;
        const value = coerceOptionValue(option, asked);
        if (value !== undefined)
            state[option.key] = value;
    }
    if (typeof requested.escMenu === 'boolean')
        opts.escMenu = requested.escMenu;
    const canvas = resolveCanvas(config);
    canvas.style.imageRendering = opts.renderFilter === 'pixelated' ? 'pixelated' : 'auto';
    const ctx2d = canvas.getContext('2d');
    if (!ctx2d)
        throw new Error('mgba: could not acquire a 2d canvas context');
    // ---------------------------------------------------------------- audio
    const audioCtx = new AudioContext();
    const workletUrl = URL.createObjectURL(new Blob([WORKLET_SOURCE], { type: 'application/javascript' }));
    try {
        await audioCtx.audioWorklet.addModule(workletUrl);
    }
    catch {
        // Backstage : Chrome refuse un worklet blob: dans une page ouverte depuis
        // le disque (file://), mais accepte la même source en URL data:.
        await audioCtx.audioWorklet.addModule(`data:text/javascript,${encodeURIComponent(WORKLET_SOURCE)}`);
    }
    finally {
        URL.revokeObjectURL(workletUrl);
    }
    const sink = new AudioWorkletNode(audioCtx, 'mgba-sink', {
        numberOfInputs: 0,
        numberOfOutputs: 1,
        outputChannelCount: [2],
    });
    const gain = audioCtx.createGain();
    gain.gain.value = Math.max(0, Math.min(1, opts.volume));
    sink.connect(gain).connect(audioCtx.destination);
    let enqueuedFrames = 0;
    let consumedFrames = 0;
    sink.port.onmessage = (e) => {
        consumedFrames = e.data;
    };
    // --------------------------------------------------------------- module
    const jsUrl = config.jsUrl ?? new URL('./mgba.js', new URL("vendor/mgba.sdk.js", playerUrl).href).href;
    const wasmUrl = config.wasmUrl ?? new URL('./mgba.wasm', jsUrl).href;
    await loadClassicScriptOnce(jsUrl);
    const g = globalThis;
    if (typeof g.createMgbaModule !== 'function') {
        throw new Error('mgba: unable to initialize runtime module from mgba.js');
    }
    const mod = await g.createMgbaModule({
        locateFile(path) {
            if (path.endsWith('.wasm'))
                return wasmUrl;
            return new URL(path, jsUrl).href;
        },
        // Backstage : le wasm peut arriver déjà en mémoire. Une page ouverte
        // depuis le disque (file://) n'a pas le droit de le télécharger.
        ...(config.wasmBinary ? {
            instantiateWasm(imports, receive) {
                WebAssembly.instantiate(config.wasmBinary, imports)
                    .then(({ instance, module }) => receive(instance, module))
                    .catch((error) => console.error('mgba: could not instantiate the WebAssembly module', error));
                return {};
            },
        } : {}),
    });
    // ----------------------------------------------------------------- boot
    mod._mgbawasm_init();
    mod._mgbawasm_set_log_level(MGBA_LOG_LEVEL_IDS[opts.logLevel]);
    /** Copies a string into the heap as NUL-terminated UTF-8 (caller frees). */
    const heapString = (value) => {
        const size = mod.lengthBytesUTF8(value) + 1;
        const ptr = mod._malloc(size);
        mod.stringToUTF8(value, ptr, size);
        return ptr;
    };
    /**
     * Boots the cartridge. Everything the core reads while mapping it — the
     * platform, the Game Boy model, the BIOS, `skipBios` — is settled here,
     * which is why the options that feed it are tagged "needs reset".
     */
    const bootCore = () => {
        const romPtr = heapAlloc(mod, romBytes);
        const biosPtr = biosBytes ? heapAlloc(mod, biosBytes) : 0;
        const gbModel = MGBA_GB_MODEL_VALUES[opts.gbModel];
        const gbModelPtr = gbModel ? heapString(gbModel) : 0;
        const ok = mod._mgbawasm_load(romPtr, romBytes.length, biosPtr, biosBytes?.length ?? 0, MGBA_PLATFORM_IDS[opts.system], gbModelPtr, opts.skipBios ? 1 : 0);
        mod._free(romPtr);
        if (biosPtr)
            mod._free(biosPtr);
        if (gbModelPtr)
            mod._free(gbModelPtr);
        if (!ok) {
            throw new Error('mgba: ROM load failed — is this a valid .gba/.gb/.gbc cartridge image?');
        }
    };
    bootCore();
    const platform = mod._mgbawasm_platform();
    const system = platform === PLATFORM_GB ? 'gb' : 'gba';
    // Without a BIOS image mGBA runs its high-level replacement, which has no
    // boot animation to play — so the option is not merely ignored, it is
    // meaningless, and the state is corrected rather than left lying.
    const hasBios = mod._mgbawasm_has_bios() === 1;
    if (!hasBios)
        opts.skipBios = true;
    /** Maps a fresh cartridge, then re-pushes everything that is not boot-time. */
    const rebootCore = () => {
        bootCore();
        applyLiveSettings();
        framerate = mod._mgbawasm_framerate_micro() / 1e6 || 60;
    };
    /** Re-pushes every option the core keeps in its own config. */
    const applyLiveSettings = () => {
        mod._mgbawasm_set_log_level(MGBA_LOG_LEVEL_IDS[opts.logLevel]);
        mod._mgbawasm_set_idle_optimization?.(IDLE_IDS[opts.idleOptimization] ?? 1);
        mod._mgbawasm_set_allow_opposing_directions?.(opts.allowOpposingDirections ? 1 : 0);
    };
    applyLiveSettings();
    let framerate = mod._mgbawasm_framerate_micro() / 1e6 || 60;
    /**
     * The rate the core is emitting at *now*, pushed to the worklet whenever it
     * moves. A GBA game raising the SOUNDBIAS resolution doubles it mid-play, so
     * this is re-read every tick rather than latched at boot.
     */
    let coreRate = 0;
    const syncCoreRate = () => {
        const rate = mod._mgbawasm_sample_rate();
        if (rate > 0 && rate !== coreRate) {
            coreRate = rate;
            sink.port.postMessage({ rate });
        }
        return coreRate;
    };
    syncCoreRate();
    // Scratch space the core drains audio into, sized for a comfortable multiple
    // of a frame's worth of stereo samples.
    const AUDIO_SCRATCH_FRAMES = 4096;
    const audioPtr = mod._malloc(AUDIO_SCRATCH_FRAMES * 2 * 2);
    // ---------------------------------------------------------- persistence
    const persistEnabled = config.persist !== null && typeof navigator !== 'undefined';
    /**
     * mGBA hands out savedata by cloning it into a fresh buffer rather than
     * exposing a live pointer, so a snapshot is taken and copied out before
     * anything else can touch the heap.
     */
    const cloneSram = () => {
        const size = mod._mgbawasm_sram_save();
        if (!size)
            return null;
        const ptr = mod._mgbawasm_sram_ptr();
        if (!ptr)
            return null;
        // Copied out of the heap rather than sliced from it, so the bytes are not
        // sitting on the WASM memory that a growth could detach.
        const bytes = new Uint8Array(size);
        bytes.set(mod.HEAPU8.subarray(ptr, ptr + size));
        return bytes;
    };
    const loadSave = (bytes) => {
        const ptr = heapAlloc(mod, bytes);
        try {
            if (!mod._mgbawasm_sram_load(ptr, bytes.length)) throw new Error('mgba: SRAM restore failed');
        } finally {
            mod._free(ptr);
        }
    };
    const restoreSram = async () => {
        if (!persistEnabled)
            return;
        const dir = await opfsDir(namespace, false);
        if (!dir)
            return;
        try {
            const handle = await dir.getFileHandle('sram.bin');
            const bytes = new Uint8Array(await (await handle.getFile()).arrayBuffer());
            if (!bytes.length)
                return;
            const ptr = heapAlloc(mod, bytes);
            mod._mgbawasm_sram_load(ptr, bytes.length);
            mod._free(ptr);
        }
        catch {
            // nothing saved yet for this namespace
        }
    };
    const persistSram = async () => {
        if (!persistEnabled)
            return;
        const bytes = cloneSram();
        if (!bytes)
            return;
        const dir = await opfsDir(namespace, true);
        if (!dir)
            return;
        try {
            const handle = await dir.getFileHandle('sram.bin', { create: true });
            const writable = await handle.createWritable();
            await writable.write(bytes);
            await writable.close();
        }
        catch {
            // persistence is best-effort
        }
    };
    await restoreSram();
    // ---------------------------------------------------------------- input
    let keyMask = 0;
    let padMask = 0;
    let sentMask = -1;
    let codeToBit = new Map();
    const pushInput = () => {
        const mask = keyMask | padMask;
        if (mask !== sentMask) {
            sentMask = mask;
            mod._mgbawasm_set_keys(mask);
        }
    };
    const buildKeymap = (map) => {
        codeToBit = new Map();
        for (const [action, code] of Object.entries(map)) {
            const dot = action.indexOf('.');
            if (!code)
                continue;
            // The handheld has one controller, so a "p1." prefix is accepted but
            // never required.
            const control = dot < 0 ? action : action.slice(dot + 1);
            const bit = KEY_BITS[control];
            if (bit !== undefined)
                codeToBit.set(code, bit);
        }
    };
    buildKeymap(DEFAULT_KEYMAP);
    const applyButton = (bit, down) => {
        if (bit === undefined)
            return false;
        const flag = 1 << bit;
        keyMask = down ? keyMask | flag : keyMask & ~flag;
        pushInput();
        return true;
    };
    const onKeyDown = (e) => {
        if (e.repeat)
            return;
        if (applyButton(codeToBit.get(e.code), true))
            e.preventDefault();
    };
    const onKeyUp = (e) => {
        if (applyButton(codeToBit.get(e.code), false))
            e.preventDefault();
    };
    if (!config.hostControls) {
        window.addEventListener('keydown', onKeyDown);
        window.addEventListener('keyup', onKeyUp);
    }
    /** Gamepad polling (standard mapping). */
    const pollGamepads = () => {
        if (!opts.gamepads || !navigator.getGamepads)
            return;
        const pad = navigator.getGamepads()[0];
        let mask = 0;
        if (pad && pad.connected) {
            const btn = (i) => !!pad.buttons[i]?.pressed;
            const ax = (i) => pad.axes[i] ?? 0;
            if (btn(0))
                mask |= 1 << KEY_BITS.a;
            if (btn(1))
                mask |= 1 << KEY_BITS.b;
            if (btn(4))
                mask |= 1 << KEY_BITS.l;
            if (btn(5))
                mask |= 1 << KEY_BITS.r;
            if (btn(8))
                mask |= 1 << KEY_BITS.select;
            if (btn(9))
                mask |= 1 << KEY_BITS.start;
            if (btn(12) || ax(1) < -0.4)
                mask |= 1 << KEY_BITS.up;
            if (btn(13) || ax(1) > 0.4)
                mask |= 1 << KEY_BITS.down;
            if (btn(14) || ax(0) < -0.4)
                mask |= 1 << KEY_BITS.left;
            if (btn(15) || ax(0) > 0.4)
                mask |= 1 << KEY_BITS.right;
        }
        if (mask !== padMask) {
            padMask = mask;
            pushInput();
        }
    };
    // Browsers may refuse to start audio without a user gesture; retry on the
    // next interaction if the context comes up suspended.
    const resumeAudio = () => {
        if (audioCtx.state === 'suspended')
            void audioCtx.resume();
    };
    window.addEventListener('pointerdown', resumeAudio);
    window.addEventListener('keydown', resumeAudio);
    // --------------------------------------------------------------- render
    // Geometry is read from the core every frame: it is 240x160 on GBA, 160x144
    // on Game Boy, and 256x224 the moment a Super Game Boy border appears.
    let imageData = null;
    let lastW = 0;
    let lastH = 0;
    // Previous frame, kept only while interframe blending is on.
    let prevFrame = null;
    /**
     * Publishes the presentation ratio two ways.
     *
     * `aspect-ratio` shapes the element. `--mgba-aspect` is the same number in a
     * form arithmetic can use, so a stylesheet can size the canvas to fit its
     * container without knowing which core is running:
     *
     *     width: min(100%, calc(100% * var(--mgba-aspect)));
     *
     * Which is not a detail a host can hardcode here: it is 1.5 on GBA, 1.11 on
     * Game Boy, 1.14 once a Super Game Boy border appears, and 1.33 when the
     * player picks `aspect: '4:3'`.
     */
    const applyAspect = () => {
        if (!lastW)
            return;
        const fourThirds = opts.aspect === '4:3';
        canvas.style.aspectRatio = fourThirds ? '4 / 3' : `${lastW} / ${lastH}`;
        canvas.style.setProperty('--mgba-aspect', String(fourThirds ? 4 / 3 : lastW / lastH));
    };
    const renderFrame = () => {
        const w = mod._mgbawasm_video_width();
        const h = mod._mgbawasm_video_height();
        if (w <= 0 || h <= 0)
            return;
        if (w !== lastW || h !== lastH || !imageData) {
            canvas.width = w;
            canvas.height = h;
            imageData = ctx2d.createImageData(w, h);
            lastW = w;
            lastH = h;
            prevFrame = null;
            applyAspect();
        }
        const ptr = mod._mgbawasm_video_ptr();
        const src = mod.HEAPU8.subarray(ptr, ptr + w * h * 4);
        if (opts.interframeBlending) {
            // The unlit GBA/GB LCDs were slow enough that a sprite drawn every other
            // frame read as half-transparent. Averaging consecutive frames restores
            // that, and is what the effect is on every other frontend too.
            const dst = imageData.data;
            if (prevFrame && prevFrame.length === src.length) {
                for (let i = 0; i < src.length; i++) {
                    dst[i] = (src[i] + prevFrame[i]) >> 1;
                }
            }
            else {
                dst.set(src);
            }
            prevFrame = Uint8ClampedArray.from(src);
        }
        else {
            imageData.data.set(src);
            prevFrame = null;
        }
        ctx2d.putImageData(imageData, 0, 0);
    };
    // ------------------------------------------------------------ main loop
    // Audio-clocked pacing: keep ~90ms of audio queued ahead of the worklet's
    // consumption. While the AudioContext is suspended (no consumption), fall
    // back to wall-clock pacing so video still runs.
    //
    // Everything here counts in source frames, not output frames — the core's
    // rate is the one that fixes how much work a frame is, and the worklet
    // reports its consumption in the same unit for exactly that reason.
    const TARGET_SECONDS = 0.09;
    const MAX_FRAMES_PER_TICK = 5;
    let rafId = 0;
    let running = false;
    let paused = false;
    let wallClockFrames = 0;
    let wallClockStart = 0;
    let fpsCount = 0;
    let fpsWindowStart = 0;
    let persistTimer = null;
    // Audio-clocked pacing only works while the audio clock actually advances.
    // A context can report `running` and still never render a quantum when there
    // is no output device (headless browsers, VMs without a sound card), and
    // then the buffer deficit never reappears and the picture freezes for good.
    // Watch AudioContext.currentTime and treat a clock that has not moved for
    // half a second as stalled, so pacing falls back to the wall clock.
    const AUDIO_STALL_MS = 500;
    let audioClockTime = -1;
    let audioClockWall = 0;
    let audioStalled = false;
    const audioClockAdvancing = (now) => {
        const t = audioCtx.currentTime;
        if (t !== audioClockTime) {
            audioClockTime = t;
            audioClockWall = now;
            audioStalled = false;
        }
        else if (now - audioClockWall > AUDIO_STALL_MS) {
            audioStalled = true;
        }
        return !audioStalled;
    };
    const drainAudio = () => {
        // Short reads are the norm: the sample count a frame produces wobbles
        // around the nominal rate, so this drains whatever is actually there.
        for (;;) {
            const frames = mod._mgbawasm_read_audio(audioPtr, AUDIO_SCRATCH_FRAMES);
            if (frames <= 0)
                return;
            const start = audioPtr >> 1;
            const chunk = mod.HEAP16.slice(start, start + frames * 2);
            sink.port.postMessage(chunk, [chunk.buffer]);
            enqueuedFrames += frames;
            if (frames < AUDIO_SCRATCH_FRAMES)
                return;
        }
    };
    const runFrames = (count) => {
        for (let i = 0; i < count; i++) {
            mod._mgbawasm_run_frame();
            drainAudio();
            fpsCount++;
        }
    };
    const tick = (now) => {
        if (!running || paused)
            return;
        rafId = requestAnimationFrame(tick);
        pollGamepads();
        const rate = syncCoreRate();
        let frames = 0;
        if (audioCtx.state === 'running' && audioClockAdvancing(now)) {
            const buffered = enqueuedFrames - consumedFrames;
            const deficit = Math.round(rate * TARGET_SECONDS) - buffered;
            const perEmulatedFrame = rate / framerate;
            if (deficit > 0)
                frames = Math.ceil(deficit / perEmulatedFrame);
            wallClockStart = 0;
        }
        else {
            // Wall-clock fallback (audio blocked or stalled): accumulate at the core
            // framerate.
            if (!wallClockStart) {
                wallClockStart = now;
                wallClockFrames = 0;
            }
            const due = Math.floor(((now - wallClockStart) / 1000) * framerate);
            frames = due - wallClockFrames;
            wallClockFrames = due;
        }
        frames = Math.max(0, Math.min(MAX_FRAMES_PER_TICK, frames));
        if (frames > 0) {
            runFrames(frames);
            renderFrame();
        }
        if (!fpsWindowStart)
            fpsWindowStart = now;
        if (now - fpsWindowStart >= 1000) {
            emit({ type: 'frame', fps: (fpsCount * 1000) / (now - fpsWindowStart) });
            fpsWindowStart = now;
            fpsCount = 0;
        }
    };
    const startLoop = () => {
        if (rafId)
            cancelAnimationFrame(rafId);
        wallClockStart = 0;
        rafId = requestAnimationFrame(tick);
    };
    const setInput = (map) => {
        if (typeof map === 'string') {
            buildKeymap(DEFAULT_KEYMAP);
        }
        else {
            buildKeymap({ ...DEFAULT_KEYMAP, ...map });
        }
    };
    // -------------------------------------------------------- live settings
    // What the cartridge was actually mapped with. A change to any of these only
    // lands on the next boot, which is what reset() below does.
    let bootedSystem = opts.system;
    let bootedGbModel = opts.gbModel;
    let bootedSkipBios = opts.skipBios;
    /**
     * How each setting reaches the running emulator. A key left out here — or
     * dropped because the loaded wasm predates its shim setter — is reported as
     * unsupported and does not appear in the menu.
     */
    const appliers = {
        renderFilter: (value) => {
            canvas.style.imageRendering = value === 'pixelated' ? 'pixelated' : 'auto';
        },
        aspect: () => applyAspect(),
        interframeBlending: () => {
            prevFrame = null;
        },
        volume: (value) => {
            gain.gain.value = Math.max(0, Math.min(1, Number(value)));
        },
        gamepads: (value) => {
            // Whatever a pad was holding when polling stopped would otherwise stay
            // pressed forever.
            if (!value) {
                padMask = 0;
                pushInput();
            }
        },
        logLevel: (value) => mod._mgbawasm_set_log_level(MGBA_LOG_LEVEL_IDS[value]),
    };
    const setIdle = mod._mgbawasm_set_idle_optimization;
    if (setIdle) {
        appliers.idleOptimization = (value) => setIdle.call(mod, IDLE_IDS[String(value)] ?? 1);
    }
    const setOpposing = mod._mgbawasm_set_allow_opposing_directions;
    if (setOpposing) {
        appliers.allowOpposingDirections = (value) => setOpposing.call(mod, value ? 1 : 0);
    }
    // Recorded now, applied by reset().
    appliers.system = () => { };
    appliers.gbModel = () => { };
    // Without a real BIOS there is no intro to skip, so the option is dropped
    // from the menu entirely rather than offered as a lie.
    if (hasBios)
        appliers.skipBios = () => { };
    const engineConfig = bindConfig(state, appliers);
    // The ESC menu lives in the host's demo shell as of engine-specs 0.2.5, so
    // this package supplies the rows and applies the writes rather than drawing
    // anything itself. Persisting on every write keeps the two in step without
    // the shell having to know that persistence exists.
    const engineWrite = engineConfig.write;
    engineConfig.write = (key, value) => {
        const ok = engineWrite(key, value);
        if (ok)
            settingsStore.save(engineConfig.values());
        return ok;
    };
    const instance = {
        config: engineConfig,
        system,
        escMenuGroups() {
            return toEscMenuGroups(engineConfig.values());
        },
        start() {
            if (running)
                return;
            running = true;
            paused = false;
            resumeAudio();
            startLoop();
            if (persistEnabled) {
                persistTimer = setInterval(() => void persistSram(), 15000);
            }
            emit({ type: 'ready' });
        },
        pause() {
            if (!running || paused)
                return;
            paused = true;
            cancelAnimationFrame(rafId);
            rafId = 0;
            void audioCtx.suspend();
            void persistSram();
        },
        resume() {
            if (!running || !paused)
                return;
            paused = false;
            void audioCtx.resume();
            startLoop();
        },
        reset() {
            const needsReboot = opts.system !== bootedSystem ||
                opts.gbModel !== bootedGbModel ||
                opts.skipBios !== bootedSkipBios;
            if (!needsReboot) {
                mod._mgbawasm_reset();
                return;
            }
            // A reboot throws the cartridge away and maps a new one, so battery RAM
            // is carried across by hand — on hardware it would have survived the
            // power cycle.
            const sram = cloneSram();
            rebootCore();
            bootedSystem = opts.system;
            bootedGbModel = opts.gbModel;
            bootedSkipBios = opts.skipBios;
            if (sram) {
                const ptr = heapAlloc(mod, sram);
                mod._mgbawasm_sram_load(ptr, sram.length);
                mod._free(ptr);
            }
        },
        setInput,
        setButton(control, down) { applyButton(KEY_BITS[control], down); },
        readSave: cloneSram,
        loadSave,
        async saveState() {
            const size = mod._mgbawasm_state_size();
            if (!size)
                throw new Error('mgba: failed to save state');
            const ptr = mod._malloc(size);
            const ok = mod._mgbawasm_state_save(ptr);
            const bytes = ok ? mod.HEAPU8.slice(ptr, ptr + size) : null;
            mod._free(ptr);
            if (!bytes)
                throw new Error('mgba: failed to save state');
            return bytes;
        },
        async loadState(data) {
            const size = mod._mgbawasm_state_size();
            if (data.length !== size) {
                throw new Error(`mgba: savestate is ${data.length} bytes but this core expects ${size} — it belongs to a different game or a different build`);
            }
            const ptr = heapAlloc(mod, data);
            const ok = mod._mgbawasm_state_load(ptr);
            mod._free(ptr);
            if (!ok)
                throw new Error('mgba: failed to load state');
        },
        async screenshot() {
            renderFrame();
            return new Promise((resolve, reject) => {
                canvas.toBlob((blob) => {
                    if (blob)
                        resolve(blob);
                    else
                        reject(new Error('mgba: screenshot failed'));
                }, 'image/png');
            });
        },
        async purgeStorage() {
            let data = false;
            try {
                const root = await navigator.storage.getDirectory();
                const engineDir = await root.getDirectoryHandle('mgba');
                await engineDir.removeEntry(namespace, { recursive: true });
                data = true;
            }
            catch {
                // nothing persisted for this namespace
            }
            settingsStore.clear();
            return { data, settings: true };
        },
        destroy() {
            running = false;
            paused = false;
            if (rafId)
                cancelAnimationFrame(rafId);
            rafId = 0;
            if (persistTimer)
                clearInterval(persistTimer);
            persistTimer = null;
            void persistSram();
            window.removeEventListener('keydown', onKeyDown);
            window.removeEventListener('keyup', onKeyUp);
            window.removeEventListener('pointerdown', resumeAudio);
            window.removeEventListener('keydown', resumeAudio);
            sink.disconnect();
            gain.disconnect();
            void audioCtx.close();
            mod._free(audioPtr);
            mod._mgbawasm_unload();
            emit({ type: 'exit' });
        },
    };
    return instance;
}
const moduleDefault = { manifest, load };

return { load, manifest, default: moduleDefault };
})();
// save.js
modules["save.js"] = (() => {
// Le moteur précédent stockait les .sav dans le volume IndexedDB /data d'Emscripten.
const SAVE_DATABASE = "/data";
const SAVE_VERSION = 21;
const SAVE_STORE = "FILE_DATA";

function readRequest(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function openCartridgeSave(romName) {
  const key = `/data/saves/${romName.replace(/\.[^.]*$/, "")}.sav`;
  const request = indexedDB.open(SAVE_DATABASE, SAVE_VERSION);
  request.onupgradeneeded = () => {
    const db = request.result;
    const store = db.objectStoreNames.contains(SAVE_STORE)
      ? request.transaction.objectStore(SAVE_STORE)
      : db.createObjectStore(SAVE_STORE);
    if (!store.indexNames.contains("timestamp")) store.createIndex("timestamp", "timestamp");
  };
  const db = await readRequest(request);
  db.onversionchange = () => db.close();

  try {
    const entry = await readRequest(db.transaction(SAVE_STORE).objectStore(SAVE_STORE).get(key));
    const contents = entry?.contents;
    let lastSave = contents;
    return {
      contents,
      close() { db.close(); },
      write(bytes) {
        if (!bytes?.length || (lastSave?.length === bytes.length &&
            bytes.every((byte, index) => byte === lastSave[index]))) return;
        const transaction = db.transaction(SAVE_STORE, "readwrite");
        // Emscripten attend un fichier normal, avec les permissions 0666.
        transaction.objectStore(SAVE_STORE).put({
          timestamp: new Date(), mode: 0o100666, contents: bytes,
        }, key);
        lastSave = bytes;
        transaction.onabort = () => {
          if (lastSave === bytes) lastSave = null;
          console.warn("Could not save the cartridge.", transaction.error);
        };
      },
    };
  } catch (error) {
    db.close();
    throw error;
  }
}

return { openCartridgeSave };
})();
// shaders.js
modules["shaders.js"] = (() => {
// Rendu des shaders de mGBA (dossiers `*.shader` décrits par `manifest.ini`)
// par-dessus l'écran de l'émulateur. La sémantique suit le rendu OpenGL de
// mGBA : chaque passe dessine dans sa propre texture, `texSize` vaut la taille
// native de la console, et une passe `blend=1` se mélange à son image
// précédente (rémanence de l'écran LCD, flou de mouvement).

const NATIVE_SIZE = [240, 160];
// Les shaders sont écrits en GLSL 1.10 ; ils compilent en GLSL ES 3.00 (WebGL 2),
// qui accepte comme mGBA l'indexation d'un tableau par une variable.
const HEADER = "#version 300 es\nprecision highp float;\n";
const DEFAULT_VERTEX = `attribute vec4 position;
varying vec2 texCoord;
void main() {
  gl_Position = position;
  texCoord = (position.st + vec2(1.0, 1.0)) * vec2(0.5, 0.5);
}`;
const DEFAULT_FRAGMENT = `varying vec2 texCoord;
uniform sampler2D tex;
void main() {
  gl_FragColor = texture2D(tex, texCoord);
}`;
const UNIFORM_SIZES = { float: 1, float2: 2, float3: 3, float4: 4 };

function parseIni(text) {
  const sections = {};
  let current = null;
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith(";") || line.startsWith("#")) continue;
    const header = line.match(/^\[(.+)\]$/);
    if (header) {
      current = sections[header[1]] = {};
      continue;
    }
    const separator = line.indexOf("=");
    if (current && separator > 0) {
      current[line.slice(0, separator).trim()] = line.slice(separator + 1).trim();
    }
  }
  return sections;
}

async function fetchText(url) {
  // Build WEB embarque les shaders dans player.js (file:// interdit fetch).
  const embedded = globalThis.BACKSTAGE_SHADER_FILES?.[new URL(url).pathname.split("/shaders/").at(-1)];
  if (embedded !== undefined) return embedded;
  const response = await fetch(url);
  if (!response.ok) throw new Error(`HTTP ${response.status} for ${url}`);
  return response.text();
}

function uniformDefault(name, section) {
  const size = UNIFORM_SIZES[section.type];
  if (!size) throw new Error(`Unsupported uniform type ${section.type} for ${name}.`);
  if (size === 1) return [Number(section.default ?? 0)];
  return Array.from({ length: size }, (_, index) => Number(section[`default[${index}]`] ?? 0));
}

/** Lit un dossier `nom.shader/` et ses fichiers GLSL. */
async function loadShader(folder) {
  const base = new URL(`shaders/${folder}/`, new URL("shaders.js", playerUrl).href);
  const manifest = parseIni(await fetchText(new URL("manifest.ini", base)));
  const passes = [];
  for (let index = 0; index < Number(manifest.shader?.passes ?? 0); index++) {
    const section = manifest[`pass.${index}`] ?? {};
    const prefix = `pass.${index}.uniform.`;
    passes.push({
      vertex: section.vertexShader ? await fetchText(new URL(section.vertexShader, base)) : DEFAULT_VERTEX,
      fragment: section.fragmentShader ? await fetchText(new URL(section.fragmentShader, base)) : DEFAULT_FRAGMENT,
      width: Number(section.width ?? 0),
      height: Number(section.height ?? 0),
      blend: section.blend === "1",
      filter: section.filter === "1",
      integerScaling: section.integerScaling === "1",
      uniforms: Object.entries(manifest)
        .filter(([name]) => name.startsWith(prefix))
        .map(([name, values]) => ({ name: name.slice(prefix.length), value: uniformDefault(name, values) })),
    });
  }
  return { name: manifest.shader?.name ?? folder, passes };
}

/** Dessine l'image d'un canvas source à travers un shader mGBA. */
class ShaderScreen {
  constructor(target, source) {
    this.target = target;
    this.source = source;
    this.passes = [];
    this.frame = 0;
    const gl = target.getContext("webgl2", { alpha: false, antialias: false, depth: false });
    if (!gl) throw new Error("WebGL 2 is not available.");
    this.gl = gl;
    this.quad = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    this.sourceTexture = this.createTexture();
    this.present = this.createProgram(DEFAULT_VERTEX, DEFAULT_FRAGMENT);
    this.draw = this.draw.bind(this);
  }

  createTexture() {
    const gl = this.gl;
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    return texture;
  }

  createProgram(vertexSource, fragmentSource) {
    const gl = this.gl;
    const program = gl.createProgram();
    const vertex = vertexSource
      .replace(/\battribute\b/g, "in")
      .replace(/\bvarying\b/g, "out");
    const fragment = "out vec4 fragColor;\n" + fragmentSource
      .replace(/\bvarying\b/g, "in")
      .replace(/\btexture2D\b/g, "texture")
      .replace(/\bgl_FragColor\b/g, "fragColor");
    for (const [type, source] of [[gl.VERTEX_SHADER, vertex], [gl.FRAGMENT_SHADER, fragment]]) {
      const shader = gl.createShader(type);
      gl.shaderSource(shader, HEADER + source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        const log = gl.getShaderInfoLog(shader);
        gl.deleteShader(shader);
        gl.deleteProgram(program);
        throw new Error(`Shader compilation failed: ${log}`);
      }
      gl.attachShader(program, shader);
      gl.deleteShader(shader);
    }
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      const log = gl.getProgramInfoLog(program);
      gl.deleteProgram(program);
      throw new Error(`Shader link failed: ${log}`);
    }
    return program;
  }

  /** Remplace le shader actif ; `null` rend la main à l'écran de l'émulateur. */
  setShader(shader) {
    const gl = this.gl;
    const passes = shader?.passes.map((pass) => ({
      ...pass,
      program: this.createProgram(pass.vertex, pass.fragment),
      texture: this.createTexture(),
      framebuffer: gl.createFramebuffer(),
      size: [0, 0],
    })) ?? [];
    for (const pass of this.passes) {
      gl.deleteProgram(pass.program);
      gl.deleteTexture(pass.texture);
      gl.deleteFramebuffer(pass.framebuffer);
    }
    this.passes = passes;
    this.target.hidden = !passes.length;
    cancelAnimationFrame(this.frame);
    if (passes.length) this.frame = requestAnimationFrame(this.draw);
  }

  passSize(pass, viewport) {
    const size = [pass.width, pass.height].map((value, axis) => {
      if (value < 0) return -value * NATIVE_SIZE[axis];
      return value || viewport[axis];
    });
    if (!pass.integerScaling) return size;
    const scale = Math.max(1, Math.floor(Math.min(size[0] / NATIVE_SIZE[0], size[1] / NATIVE_SIZE[1])));
    return NATIVE_SIZE.map((value) => value * scale);
  }

  drawQuad(program, input, filter) {
    const gl = this.gl;
    gl.useProgram(program);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, input);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
    gl.uniform1i(gl.getUniformLocation(program, "tex"), 0);
    gl.uniform2fv(gl.getUniformLocation(program, "texSize"), NATIVE_SIZE);
    const position = gl.getAttribLocation(program, "position");
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.enableVertexAttribArray(position);
    gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }

  draw() {
    const gl = this.gl;
    const ratio = devicePixelRatio || 1;
    const viewport = [
      Math.max(1, Math.round(this.target.clientWidth * ratio)),
      Math.max(1, Math.round(this.target.clientHeight * ratio)),
    ];
    if (this.target.width !== viewport[0] || this.target.height !== viewport[1]) {
      [this.target.width, this.target.height] = viewport;
    }

    // Le canvas WebGL range sa première ligne en bas : l'image source est retournée à l'envoi.
    gl.bindTexture(gl.TEXTURE_2D, this.sourceTexture);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.source);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);

    let input = this.sourceTexture;
    for (const pass of this.passes) {
      const size = this.passSize(pass, viewport);
      gl.bindTexture(gl.TEXTURE_2D, pass.texture);
      if (pass.size[0] !== size[0] || pass.size[1] !== size[1]) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, size[0], size[1], 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        gl.bindFramebuffer(gl.FRAMEBUFFER, pass.framebuffer);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, pass.texture, 0);
        pass.size = size;
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, pass.framebuffer);
      gl.viewport(0, 0, size[0], size[1]);
      if (pass.blend) {
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      } else {
        gl.disable(gl.BLEND);
        gl.clearColor(0, 0, 0, 0);
        gl.clear(gl.COLOR_BUFFER_BIT);
      }
      gl.useProgram(pass.program);
      for (const uniform of pass.uniforms) {
        const location = gl.getUniformLocation(pass.program, uniform.name);
        gl[`uniform${uniform.value.length}fv`](location, uniform.value);
      }
      this.drawQuad(pass.program, input, pass.filter ? gl.LINEAR : gl.NEAREST);
      input = pass.texture;
    }

    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, viewport[0], viewport[1]);
    gl.disable(gl.BLEND);
    this.drawQuad(this.present, input, gl.LINEAR);
    this.frame = requestAnimationFrame(this.draw);
  }
}

return { loadShader, ShaderScreen };
})();
// main.js
modules["main.js"] = (() => {
const { load } = modules["vendor/mgba.sdk.js"];
const { openCartridgeSave } = modules["save.js"];
const { loadShader, ShaderScreen } = modules["shaders.js"];

const canvas = document.querySelector("#screen");
const curtain = document.querySelector("#curtain");
const status = document.querySelector("#status");
const romInput = document.querySelector("#rom-file");
const playButton = document.querySelector("#play");
const bundledRom = playButton.dataset.rom;
romInput.closest("label").hidden = Boolean(bundledRom);
const muteButton = document.querySelector("#mute");
const fullscreenButton = document.querySelector("#fullscreen");
const mobilePreviewButton = document.querySelector("#mobile-preview");
const prototype = document.querySelector(".web-prototype");
const compatibility = document.querySelector("#compatibility");
const touchLayout = document.querySelector("#touch-layout");
const previewOrientation = document.querySelector("#preview-orientation");
const player = document.querySelector(".player");
const frameStyle = document.querySelector("#frame-style");
const framePicker = document.querySelector("#frame-picker");
const frameFile = document.querySelector("#frame-file");
const frameStatus = document.querySelector("#frame-status");
const touchPointer = matchMedia("(pointer: coarse)");
const isItch = /(^|\.)itch\.(io|zone)$/.test(location.hostname);
const isFirefoxAndroid = /\bAndroid\b.*\bFirefox\//.test(navigator.userAgent);
const landscapeViewport = matchMedia("(orientation: landscape)");
const gamepadStatus = document.querySelector("#gamepad-status");
const controlsToggle = document.querySelector("#controls-toggle");
const controlsPanel = document.querySelector("#controls-panel");
const mappingButtons = document.querySelectorAll("[data-map-control]");
const shaderButton = document.querySelector("#shader-cycle");
const shaderCanvas = document.querySelector("#shader-screen");
const shaderName = document.querySelector("#shader-name");
// Ordre du cycle du bouton shader ; "" = aucun. Les noms affichés viennent des manifest.ini.
const SHADER_CYCLE = [
  "", "lcd.shader", "gba-color.shader", "agb001.shader", "ags001.shader",
  "scanlines.shader", "tv-mode.shader", "vba_pixelate.shader", "scale2x.shader",
  "scale4x.shader", "soften.shader", "motion_blur.shader", "vignette.shader", "wiiu.shader",
];

const STORAGE_KEY = "backstage-html-proto-controls";
const DEFAULT_GAMEPAD_MAPPING = {
  up: 12, down: 13, left: 14, right: 15,
  a: 0, b: 1, l: 4, r: 5, start: 9, select: 8,
};
// Touches physiques (KeyboardEvent.code) : la position ne dépend pas de la
// disposition du clavier, seul le libellé affiché en dépend.
const DEFAULT_KEYBOARD_MAPPING = {
  up: "ArrowUp", down: "ArrowDown", left: "ArrowLeft", right: "ArrowRight",
  a: "KeyZ", b: "KeyX", l: "KeyQ", r: "KeyE", start: "Enter", select: "ShiftRight",
};
const CONTROL_NAMES = {
  up: "Haut", down: "Bas", left: "Gauche", right: "Droite",
  a: "A", b: "B", l: "L", r: "R", select: "Select", start: "Start",
};
const KEY_NAMES = {
  ArrowUp: "↑", ArrowDown: "↓", ArrowLeft: "←", ArrowRight: "→",
  Enter: "Entrée", Space: "Espace", Backspace: "Retour arrière", Tab: "Tab",
  ShiftLeft: "Maj. gauche", ShiftRight: "Maj. droite",
  ControlLeft: "Ctrl gauche", ControlRight: "Ctrl droite",
  AltLeft: "Alt", AltRight: "Alt Gr",
};

let emulator;
let cartridgeSave;
let gameRunning = false;
let selectedRom;
let frameUrl;
let muted = false;
// Affectation en cours de saisie : { device: "keyboard" | "gamepad", control }.
let capture = null;
let keyboardLayout = null;
const heldKeys = new Map();
let previousButtons = [];
const activeInputs = new Map();
let savedControls = {};
try {
  savedControls = JSON.parse(localStorage.getItem(STORAGE_KEY)) ?? {};
} catch {
  // Un cadre intégré peut interdire l'accès au stockage.
}
const gamepadMapping = { ...DEFAULT_GAMEPAD_MAPPING, ...savedControls.gamepad };
const keyboardMapping = { ...DEFAULT_KEYBOARD_MAPPING, ...savedControls.keyboard };

function setStatus(message) {
  status.textContent = message;
}

function setControlsEnabled(enabled) {
  muteButton.disabled = !enabled;
  fullscreenButton.disabled = !enabled || !document.fullscreenEnabled;
}

function saveControls() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      // Le choix du contour n'existe que dans la page du prototype.
      ...(frameStyle && { frameStyle: frameStyle.value === "image" ? "backstage" : frameStyle.value }),
      gamepad: gamepadMapping,
      keyboard: keyboardMapping,
      shader: shaderFolder,
    }));
  } catch {
    // Les réglages restent utilisables pendant la session.
  }
}

function press(control, source) {
  if (!gameRunning) return;
  const sources = activeInputs.get(control) || new Set();
  if (!sources.size) emulator.setButton(control, true);
  sources.add(source);
  activeInputs.set(control, sources);
}

function release(control, source) {
  const sources = activeInputs.get(control);
  if (!sources) return;
  sources.delete(source);
  if (!sources.size) {
    emulator?.setButton(control, false);
    activeInputs.delete(control);
  }
}

function keyName(code) {
  const label = keyboardLayout?.get(code);
  if (label && label.trim()) return label.toUpperCase();
  return KEY_NAMES[code] ?? code.replace(/^(Key|Digit)/, "");
}

function refreshMappingButtons() {
  mappingButtons.forEach((button) => {
    const { mapDevice: device, mapControl: control } = button.dataset;
    const name = CONTROL_NAMES[control];
    const keyboard = device === "keyboard";
    const assignment = keyboard ? keyName(keyboardMapping[control]) : `Bouton ${gamepadMapping[control] + 1}`;
    const listening = capture?.device === device && capture.control === control;
    button.textContent = listening ? "…" : assignment;
    button.classList.toggle("listening", listening);
    button.setAttribute("aria-label", listening
      ? `${keyboard ? "Appuie sur une touche du clavier" : "Appuie sur un bouton de la manette"} pour ${name}. Échap ou un second clic pour annuler.`
      : `Modifier ${keyboard ? "la touche" : "le bouton de manette"} de ${name}, ${assignment}`);
  });
}

function pollGamepad() {
  let gamepad;
  try {
    gamepad = [...navigator.getGamepads()].find(Boolean);
  } catch {
    gamepadStatus.textContent = "La manette n’est pas disponible dans ce cadre.";
    return;
  }
  if (gamepad) {
    gamepadStatus.textContent = `Manette connectée : ${gamepad.id}`;
    const pressedButtons = gamepad.buttons.map((button) => button.pressed || button.value > .6);
    if (capture?.device === "gamepad") {
      const captured = pressedButtons.findIndex((pressed, index) => pressed && !previousButtons[index]);
      if (captured >= 0) {
        gamepadMapping[capture.control] = captured;
        capture = null;
        saveControls();
        refreshMappingButtons();
      }
    }
    for (const [control, buttonIndex] of Object.entries(gamepadMapping)) {
      const source = `gamepad-${control}`;
      const stickPressed = {
        left: gamepad.axes[0] < -.55,
        right: gamepad.axes[0] > .55,
        up: gamepad.axes[1] < -.55,
        down: gamepad.axes[1] > .55,
      }[control] || false;
      if (pressedButtons[buttonIndex] || stickPressed) press(control, source);
      else release(control, source);
    }
    previousButtons = pressedButtons;
  } else {
    gamepadStatus.textContent = "Branche une manette ou appuie sur l’un de ses boutons.";
    previousButtons = [];
  }
  requestAnimationFrame(pollGamepad);
}

// Build WEB embarque la ROM (rom.js) et le moteur (vendor/mgba.wasm.js) en base64 :
// une page ouverte depuis le disque (file://) n'a pas le droit de les télécharger.
function decodeBase64(text) {
  const binary = atob(text);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index++) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

const engineWasm = globalThis.BACKSTAGE_MGBA_WASM ? decodeBase64(globalThis.BACKSTAGE_MGBA_WASM) : undefined;

function reportSaveError(error) {
  console.warn("Cartridge save unavailable.", error);
  compatibility.textContent = "La sauvegarde du jeu n’est pas accessible dans ce navigateur.";
}

function syncSave() {
  if (!gameRunning || !cartridgeSave) return;
  try {
    cartridgeSave.write(emulator.readSave());
  } catch (error) {
    reportSaveError(error);
  }
}

async function prepareRom(rom) {
  selectedRom = rom;
  playButton.disabled = true;
  emulator?.destroy();
  emulator = null;
  cartridgeSave?.close();
  cartridgeSave = null;
  if (!rom) {
    setStatus("Choisis une ROM .gba");
    return;
  }

  setStatus("Préparation de l’émulateur…");
  let save;
  try {
    save = await openCartridgeSave(rom.name).catch(reportSaveError);
    if (selectedRom !== rom) {
      save?.close();
      return;
    }
    const engine = await load({
      canvasEl: canvas,
      assets: { rom: new Uint8Array(await rom.arrayBuffer()) },
      wasmBinary: engineWasm,
      hostControls: true,
      persist: null,
      options: { system: "gba", gamepads: false, escMenu: false, volume: 1 },
    });
    if (selectedRom !== rom) {
      engine.destroy();
      save?.close();
      return;
    }
    if (save?.contents?.length) {
      try {
        engine.loadSave(new Uint8Array(save.contents));
      } catch (error) {
        reportSaveError(error);
        save.close();
        save = null;
      }
    }
    emulator = engine;
    cartridgeSave = save;
    setStatus(`${rom.name} est prête.`);
    playButton.disabled = false;
  } catch (error) {
    save?.close();
    if (selectedRom !== rom) return;
    console.error(error);
    setStatus("Impossible de préparer l’émulateur pour cette ROM.");
  }
}

async function boot() {
  if (!bundledRom) {
    setStatus("Choisis une ROM .gba");
    return;
  }
  try {
    await prepareRom(new File([decodeBase64(globalThis.BACKSTAGE_ROM)], bundledRom));
  } catch (error) {
    console.error(error);
    setStatus("Impossible de charger la ROM du paquet.");
  }
}

romInput.addEventListener("change", () => {
  if (!gameRunning) prepareRom(romInput.files?.[0]);
});

async function unlockItchOrientation() {
  if (!isItch || window === window.top || !touchPointer.matches || !screen.orientation?.unlock) return;
  try {
    // Sur Firefox, le plein écran du cadre itch.io ne suffit pas pour libérer
    // l'orientation : le document du jeu doit aussi être en plein écran.
    if (isFirefoxAndroid && !document.fullscreenElement && document.fullscreenEnabled) {
      await document.documentElement.requestFullscreen();
    }
    screen.orientation.unlock();
  } catch (error) {
    console.debug("Could not unlock screen orientation", error);
  }
}

playButton.addEventListener("click", () => {
  if (!selectedRom || !emulator) return;
  unlockItchOrientation();
  playButton.disabled = true;
  emulator.start();
  gameRunning = true;
  curtain.classList.add("hidden");
  canvas.inert = false;
  canvas.focus();
  setControlsEnabled(true);
});

muteButton.addEventListener("click", () => {
  muted = !muted;
  emulator.config.write("volume", muted ? 0 : 1);
  muteButton.title = muted ? "Activer le son" : "Couper le son";
  muteButton.setAttribute("aria-label", muteButton.title);
  muteButton.toggleAttribute("data-muted", muted);
});

fullscreenButton.addEventListener("click", async () => {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await player.requestFullscreen();
  } catch {
    compatibility.textContent = "Le plein écran n’est pas disponible dans ce cadre.";
  }
});

document.addEventListener("fullscreenchange", () => {
  const title = document.fullscreenElement ? "Quitter le plein écran" : "Plein écran";
  fullscreenButton.title = title;
  fullscreenButton.setAttribute("aria-label", title);
});

// La vue mobile et le choix du contour n'existent que dans la page du prototype :
// le gabarit exporté les retire, le contour y est fixé par le build.
mobilePreviewButton?.addEventListener("click", () => {
  const active = prototype.classList.toggle("mobile-preview");
  mobilePreviewButton.setAttribute("aria-pressed", String(active));
  previewOrientation.hidden = !active;
  if (active) setControlsPanelOpen(false);
  updateTouchLayout();
});

function updateTouchLayout() {
  const preview = prototype.classList.contains("mobile-preview");
  const landscapeScreen = screen.orientation?.type.startsWith("landscape");
  const landscape = preview ? touchLayout.value === "landscape"
    : touchPointer.matches && (landscapeViewport.matches || landscapeScreen);
  prototype.classList.toggle("preview-landscape", preview && landscape);
  player.classList.toggle("side-controls", landscape);
}

updateTouchLayout();
touchPointer.addEventListener("change", updateTouchLayout);
landscapeViewport.addEventListener("change", updateTouchLayout);
screen.orientation?.addEventListener("change", updateTouchLayout);
touchLayout?.addEventListener("change", updateTouchLayout);

function setControlsPanelOpen(open) {
  controlsPanel.hidden = !open;
  controlsToggle.setAttribute("aria-expanded", String(open));
  if (!open && capture) {
    capture = null;
    refreshMappingButtons();
  }
}

controlsToggle.addEventListener("click", () => setControlsPanelOpen(controlsPanel.hidden));

function updateFrame() {
  const style = frameStyle.value;
  player.dataset.frame = style === "image" && !frameUrl ? "none" : style;
  framePicker.hidden = style !== "image";
}

if (frameStyle) {
  frameStyle.value = savedControls.frameStyle ?? "backstage";
  if (!frameStyle.value || frameStyle.value === "image") frameStyle.value = "backstage";
  updateFrame();
  frameStyle.addEventListener("change", () => {
    updateFrame();
    saveControls();
  });
}

frameFile?.addEventListener("change", async () => {
  const file = frameFile.files[0];
  if (!file) return;

  const url = URL.createObjectURL(file);
  const image = new Image();
  image.src = url;
  frameStatus.textContent = "";
  try {
    await image.decode();
  } catch {
    URL.revokeObjectURL(url);
    if (frameFile.files[0] === file) frameStatus.textContent = "Cette image ne peut pas être ouverte.";
    return;
  }
  if (frameFile.files[0] !== file) {
    URL.revokeObjectURL(url);
    return;
  }
  // Le contour suit la grille native 272 × 208 : une autre taille décalerait le jeu.
  // Une image matricielle doit en être un multiple exact ; un SVG, vectoriel, doit
  // seulement en avoir les proportions (largeur et hauteur ou viewBox).
  const { naturalWidth: width, naturalHeight: height } = image;
  const svg = file.type === "image/svg+xml";
  const scale = width / 272;
  const fits = svg
    ? width > 0 && Math.abs(width * 208 - height * 272) <= width * 2
    : Number.isInteger(scale) && scale >= 1 && height === 208 * scale;
  if (!fits) {
    URL.revokeObjectURL(url);
    frameStatus.textContent = svg
      ? `Le SVG mesure ${width} × ${height} ; il lui faut les proportions de 272 × 208.`
      : `L’image mesure ${width} × ${height} px ; il faut 272 × 208 px ou un multiple exact.`;
    return;
  }

  if (frameUrl) URL.revokeObjectURL(frameUrl);
  frameUrl = url;
  player.style.setProperty("--frame-image", `url("${url}")`);
  updateFrame();
});

mappingButtons.forEach((button) => button.addEventListener("click", () => {
  const { mapDevice: device, mapControl: control } = button.dataset;
  capture = capture?.device === device && capture.control === control ? null : { device, control };
  refreshMappingButtons();
}));

function releaseHeldKeys() {
  for (const [code, control] of heldKeys) release(control, `key-${code}`);
  heldKeys.clear();
}

document.addEventListener("keydown", (event) => {
  if (capture) {
    if (event.code !== "Escape" && capture.device !== "keyboard") return;
    event.preventDefault();
    if (event.code !== "Escape") {
      // Une touche ne commande qu'une action : celle qui l'avait prend l'ancienne touche.
      for (const control of Object.keys(keyboardMapping)) {
        if (keyboardMapping[control] === event.code) keyboardMapping[control] = keyboardMapping[capture.control];
      }
      keyboardMapping[capture.control] = event.code;
      saveControls();
    }
    capture = null;
    refreshMappingButtons();
    return;
  }
  // Le jeu ne lit le clavier qu'une fois lancé, et laisse les champs et
  // l'activation des boutons au navigateur.
  if (!curtain.classList.contains("hidden") || event.target.closest("input, select, textarea")) return;
  if (event.target.closest("button") && ["Enter", "Space"].includes(event.code)) return;
  const control = Object.keys(keyboardMapping).find((name) => keyboardMapping[name] === event.code);
  if (!control) return;
  event.preventDefault();
  if (event.repeat || heldKeys.has(event.code)) return;
  heldKeys.set(event.code, control);
  press(control, `key-${event.code}`);
});

document.addEventListener("keyup", (event) => {
  const control = heldKeys.get(event.code);
  if (!control) return;
  heldKeys.delete(event.code);
  release(control, `key-${event.code}`);
});

window.addEventListener("blur", releaseHeldKeys);

// Libellés des touches selon la disposition réelle du clavier, si le navigateur la donne.
navigator.keyboard?.getLayoutMap?.().then((layout) => {
  keyboardLayout = layout;
  refreshMappingButtons();
}).catch(() => {});

document.querySelectorAll("[data-control]").forEach((button) => {
  const control = button.dataset.control;
  const touches = new Map();
  button.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || touches.has(event.pointerId)) return;
    event.preventDefault();
    button.setPointerCapture(event.pointerId);
    // Un nouvel appui peut réutiliser le même pointerId avant la fin du délai.
    const source = Symbol();
    touches.set(event.pointerId, { source, started: performance.now() });
    press(control, source);
  });
  for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
    button.addEventListener(eventName, (event) => {
      const touch = touches.get(event.pointerId);
      if (!touch) return;
      touches.delete(event.pointerId);
      // L'émulateur doit pouvoir lire un appui bref sur au moins une frame.
      const delay = eventName === "pointerup" ? 45 - (performance.now() - touch.started) : 0;
      if (delay > 0) setTimeout(() => release(control, touch.source), delay);
      else release(control, touch.source);
    });
  }
});

// Pavé directionnel à glisser : la position du doigt choisit l'un des huit
// secteurs de 45°, ce qui donne les diagonales sans viser deux boutons.
const stick = document.querySelector(".touch-stick");
const stickKnob = stick.querySelector(".stick-knob");
const STICK_SECTORS = [
  ["right"], ["right", "down"], ["down"], ["left", "down"],
  ["left"], ["left", "up"], ["up"], ["right", "up"],
];
const stickHeld = new Map();
let stickPointer = null;
let stickPresses = 0;

function setStickDirections(directions) {
  for (const [direction, held] of stickHeld) {
    if (directions.includes(direction)) continue;
    stickHeld.delete(direction);
    // Même garde que les boutons : un appui reste actif au moins 45 ms.
    setTimeout(() => release(direction, held.source), Math.max(0, 45 - (performance.now() - held.started)));
  }
  for (const direction of directions) {
    if (stickHeld.has(direction)) continue;
    const source = `stick-${direction}-${stickPresses++}`;
    stickHeld.set(direction, { source, started: performance.now() });
    press(direction, source);
  }
  stick.querySelectorAll(".stick-mark").forEach((mark) => {
    mark.classList.toggle("lit", stickHeld.has(mark.dataset.direction));
  });
}

function moveStick(event) {
  const rect = stick.getBoundingClientRect();
  const radius = rect.width / 2;
  const dx = event.clientX - (rect.left + radius);
  const dy = event.clientY - (rect.top + radius);
  const distance = Math.hypot(dx, dy);
  const travel = Math.min(distance, radius * .5);
  const scale = distance ? travel / distance : 0;
  stickKnob.style.translate = `${dx * scale}px ${dy * scale}px`;
  if (distance < radius * .25) {
    setStickDirections([]);
    return;
  }
  const sector = (Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) + 8) % 8;
  setStickDirections(STICK_SECTORS[sector]);
}

function releaseStick(event) {
  if (event.pointerId !== stickPointer) return;
  stickPointer = null;
  stick.classList.remove("held");
  stickKnob.style.translate = "";
  setStickDirections([]);
}

stick.addEventListener("pointerdown", (event) => {
  if (stickPointer !== null) return;
  event.preventDefault();
  stick.setPointerCapture(event.pointerId);
  stickPointer = event.pointerId;
  stick.classList.add("held");
  moveStick(event);
});
stick.addEventListener("pointermove", (event) => {
  if (event.pointerId === stickPointer) moveStick(event);
});
for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
  stick.addEventListener(eventName, releaseStick);
}

let shaderScreen;
let shaderFolder = SHADER_CYCLE.includes(savedControls.shader) ? savedControls.shader : "";
let shaderNameTimer = 0;
try {
  shaderScreen = new ShaderScreen(shaderCanvas, canvas);
} catch (error) {
  console.error(error);
  shaderButton.hidden = true;
}

function showShaderName(name) {
  shaderName.textContent = name;
  shaderName.hidden = false;
  clearTimeout(shaderNameTimer);
  shaderNameTimer = setTimeout(() => { shaderName.hidden = true; }, 1200);
}

async function applyShader({ announce }) {
  const folder = shaderFolder;
  let name = "Aucun shader";
  try {
    const shader = folder ? await loadShader(folder) : null;
    if (folder !== shaderFolder) return;
    shaderScreen.setShader(shader);
    if (shader) name = shader.name;
  } catch (error) {
    console.error(error);
    compatibility.textContent = "Ce shader ne fonctionne pas dans ce navigateur.";
    shaderFolder = "";
    shaderScreen.setShader(null);
  }
  shaderButton.setAttribute("aria-pressed", String(Boolean(shaderFolder)));
  shaderButton.title = `Shader : ${shaderFolder ? name : "aucun"}`;
  shaderButton.setAttribute("aria-label", shaderButton.title);
  if (announce) showShaderName(name);
  saveControls();
}

if (shaderScreen) {
  applyShader({ announce: false });
  shaderButton.addEventListener("click", () => {
    shaderFolder = SHADER_CYCLE[(SHADER_CYCLE.indexOf(shaderFolder) + 1) % SHADER_CYCLE.length];
    applyShader({ announce: true });
  });
}

setInterval(syncSave, 5000);
window.addEventListener("pagehide", syncSave);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) syncSave();
});
refreshMappingButtons();
pollGamepad();
boot();

return {  };
})();
})();
